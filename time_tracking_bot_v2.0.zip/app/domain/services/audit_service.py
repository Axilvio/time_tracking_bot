from datetime import datetime
from typing import Dict, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.audit_log import AuditLog
from app.infrastructure.repositories.audit_repo import AuditRepository


class AuditService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.audit_repo = AuditRepository(db)
    
    async def log_action(
        self,
        user_id: Optional[int],
        action: str,
        details: Optional[Dict] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> AuditLog:
        """Log an action to the audit log."""
        audit_log = await self.audit_repo.create({
            "user_id": user_id,
            "action": action,
            "details": details,
            "ip_address": ip_address,
            "user_agent": user_agent
        })
        return audit_log
    
    async def get_audit_logs(
        self,
        skip: int = 0,
        limit: int = 100,
        user_id: Optional[int] = None,
        action: Optional[str] = None
    ) -> list[AuditLog]:
        """Get audit logs with optional filtering."""
        return await self.audit_repo.get_filtered(
            skip=skip,
            limit=limit,
            user_id=user_id,
            action=action
        )