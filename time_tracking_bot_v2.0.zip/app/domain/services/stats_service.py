from datetime import date, datetime, timedelta
from typing import Dict, List

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import func, and_

from app.infrastructure.repositories.work_repo import WorkSessionRepository
from app.infrastructure.repositories.break_repo import BreakRepository
from app.infrastructure.repositories.leave_repo import LeaveRepository
from app.infrastructure.repositories.user_repo import UserRepository


class StatsService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.work_repo = WorkSessionRepository(db)
        self.break_repo = BreakRepository(db)
        self.leave_repo = LeaveRepository(db)
        self.user_repo = UserRepository(db)
    
    async def get_weekly_stats(self, user_id: int, week_start: date) -> Dict:
        """Get weekly work statistics."""
        # Calculate week end (Sunday)
        week_end = week_start + timedelta(days=6)
        
        # Get work sessions for the week
        work_sessions = await self.work_repo.get_by_user_id_and_date_range(
            user_id=user_id,
            start_date=week_start,
            end_date=week_end
        )
        
        # Calculate stats
        total_work_seconds = 0
        total_break_seconds = 0
        work_days = 0
        
        for session in work_sessions:
            if session.end:
                # Calculate work duration
                work_duration = (session.end - session.start).total_seconds()
                total_work_seconds += work_duration
                work_days += 1
                
                # Calculate break duration
                breaks = await self.break_repo.get_by_work_session_id(session.id)
                for break_session in breaks:
                    if break_session.end:
                        break_duration = (break_session.end - break_session.start).total_seconds()
                        total_break_seconds += break_duration
        
        # Calculate effective work time and overtime
        effective_work_seconds = total_work_seconds - total_break_seconds
        standard_work_seconds = work_days * 8 * 3600  # 8 hours per day
        overtime_seconds = max(0, effective_work_seconds - standard_work_seconds)
        
        # Convert to hours and minutes
        def seconds_to_time(seconds):
            hours, remainder = divmod(int(seconds), 3600)
            minutes = remainder // 60
            return f"{hours}h {minutes}m"
        
        # Calculate average work time
        avg_work_seconds = effective_work_seconds / work_days if work_days > 0 else 0
        
        return {
            "week_start": week_start.isoformat(),
            "week_end": week_end.isoformat(),
            "total_work_time": seconds_to_time(total_work_seconds),
            "total_break_time": seconds_to_time(total_break_seconds),
            "effective_work_time": seconds_to_time(effective_work_seconds),
            "work_days": work_days,
            "average_work_time": seconds_to_time(avg_work_seconds),
            "overtime": seconds_to_time(overtime_seconds)
        }
    
    async def get_monthly_stats(self, user_id: int, year: int, month: int) -> Dict:
        """Get monthly work statistics."""
        # Calculate month start and end
        month_start = date(year, month, 1)
        if month == 12:
            month_end = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            month_end = date(year, month + 1, 1) - timedelta(days=1)
        
        # Get work sessions for the month
        work_sessions = await self.work_repo.get_by_user_id_and_date_range(
            user_id=user_id,
            start_date=month_start,
            end_date=month_end
        )
        
        # Calculate stats
        total_work_seconds = 0
        total_break_seconds = 0
        work_days = 0
        
        for session in work_sessions:
            if session.end:
                # Calculate work duration
                work_duration = (session.end - session.start).total_seconds()
                total_work_seconds += work_duration
                work_days += 1
                
                # Calculate break duration
                breaks = await self.break_repo.get_by_work_session_id(session.id)
                for break_session in breaks:
                    if break_session.end:
                        break_duration = (break_session.end - break_session.start).total_seconds()
                        total_break_seconds += break_duration
        
        # Calculate effective work time and overtime
        effective_work_seconds = total_work_seconds - total_break_seconds
        standard_work_seconds = work_days * 8 * 3600  # 8 hours per day
        overtime_seconds = max(0, effective_work_seconds - standard_work_seconds)
        
        # Convert to hours and minutes
        def seconds_to_time(seconds):
            hours, remainder = divmod(int(seconds), 3600)
            minutes = remainder // 60
            return f"{hours}h {minutes}m"
        
        # Calculate average work time
        avg_work_seconds = effective_work_seconds / work_days if work_days > 0 else 0
        
        return {
            "year": year,
            "month": month,
            "total_work_time": seconds_to_time(total_work_seconds),
            "total_break_time": seconds_to_time(total_break_seconds),
            "effective_work_time": seconds_to_time(effective_work_seconds),
            "work_days": work_days,
            "average_work_time": seconds_to_time(avg_work_seconds),
            "overtime": seconds_to_time(overtime_seconds)
        }
    
    async def get_user_stats(
        self,
        user_id: int,
        start_date: date,
        end_date: date
    ) -> Dict:
        """Get statistics for a specific user."""
        # Get work sessions for the date range
        work_sessions = await self.work_repo.get_by_user_id_and_date_range(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date
        )
        
        # Calculate stats
        total_work_seconds = 0
        total_break_seconds = 0
        work_days = 0
        
        for session in work_sessions:
            if session.end:
                # Calculate work duration
                work_duration = (session.end - session.start).total_seconds()
                total_work_seconds += work_duration
                work_days += 1
                
                # Calculate break duration
                breaks = await self.break_repo.get_by_work_session_id(session.id)
                for break_session in breaks:
                    if break_session.end:
                        break_duration = (break_session.end - break_session.start).total_seconds()
                        total_break_seconds += break_duration
        
        # Calculate effective work time and overtime
        effective_work_seconds = total_work_seconds - total_break_seconds
        standard_work_seconds = work_days * 8 * 3600  # 8 hours per day
        overtime_seconds = max(0, effective_work_seconds - standard_work_seconds)
        
        # Convert to hours and minutes
        def seconds_to_time(seconds):
            hours, remainder = divmod(int(seconds), 3600)
            minutes = remainder // 60
            return f"{hours}h {minutes}m"
        
        # Calculate average work time
        avg_work_seconds = effective_work_seconds / work_days if work_days > 0 else 0
        
        return {
            "user_id": user_id,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "total_work_time": seconds_to_time(total_work_seconds),
            "total_break_time": seconds_to_time(total_break_seconds),
            "effective_work_time": seconds_to_time(effective_work_seconds),
            "work_days": work_days,
            "average_work_time": seconds_to_time(avg_work_seconds),
            "overtime": seconds_to_time(overtime_seconds)
        }
    
    async def get_admin_stats(
        self,
        start_date: date,
        end_date: date
    ) -> Dict:
        """Get admin overview statistics."""
        # Get total users
        total_users = await self.user_repo.count()
        
        # Get active users (users with work sessions in the date range)
        active_users = await self.work_repo.count_unique_users_in_date_range(
            start_date=start_date,
            end_date=end_date
        )
        
        # Get all work sessions in the date range
        work_sessions = await self.work_repo.get_by_date_range(
            start_date=start_date,
            end_date=end_date
        )
        
        # Calculate stats
        total_work_seconds = 0
        total_break_seconds = 0
        
        for session in work_sessions:
            if session.end:
                # Calculate work duration
                work_duration = (session.end - session.start).total_seconds()
                total_work_seconds += work_duration
                
                # Calculate break duration
                breaks = await self.break_repo.get_by_work_session_id(session.id)
                for break_session in breaks:
                    if break_session.end:
                        break_duration = (break_session.end - break_session.start).total_seconds()
                        total_break_seconds += break_duration
        
        # Calculate effective work time
        effective_work_seconds = total_work_seconds - total_break_seconds
        
        # Convert to hours and minutes
        def seconds_to_time(seconds):
            hours, remainder = divmod(int(seconds), 3600)
            minutes = remainder // 60
            return f"{hours}h {minutes}m"
        
        # Calculate average work time per user
        avg_work_seconds = effective_work_seconds / active_users if active_users > 0 else 0
        
        # Get top performers (users with most effective work time)
        top_performers = await self.work_repo.get_top_performers(
            start_date=start_date,
            end_date=end_date,
            limit=10
        )
        
        return {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "total_users": total_users,
            "active_users": active_users,
            "total_work_time": seconds_to_time(total_work_seconds),
            "total_break_time": seconds_to_time(total_break_seconds),
            "effective_work_time": seconds_to_time(effective_work_seconds),
            "average_work_time_per_user": seconds_to_time(avg_work_seconds),
            "top_performers": top_performers
        }
    
    async def get_work_session_stats(
        self,
        user_id: int,
        start_date: date,
        end_date: date
    ) -> List[Dict]:
        """Get detailed work session statistics."""
        # Get work sessions for the date range
        work_sessions = await self.work_repo.get_by_user_id_and_date_range(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date
        )
        
        # Calculate stats for each session
        session_stats = []
        for session in work_sessions:
            # Calculate break time for this session
            breaks = await self.break_repo.get_by_work_session_id(session.id)
            total_break_seconds = 0
            
            for break_session in breaks:
                if break_session.end:
                    break_duration = (break_session.end - break_session.start).total_seconds()
                    total_break_seconds += break_duration
            
            # Convert to hours and minutes
            def seconds_to_time(seconds):
                hours, remainder = divmod(int(seconds), 3600)
                minutes = remainder // 60
                return f"{hours}h {minutes}m"
            
            # Calculate work duration
            work_duration = None
            if session.end:
                work_duration = seconds_to_time((session.end - session.start).total_seconds())
            
            session_stats.append({
                "id": session.id,
                "date": session.start.date().isoformat(),
                "start_time": session.start.isoformat(),
                "end_time": session.end.isoformat() if session.end else None,
                "duration": work_duration,
                "location": session.location,
                "break_time": seconds_to_time(total_break_seconds)
            })
        
        return session_stats