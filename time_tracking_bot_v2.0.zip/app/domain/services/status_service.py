from datetime import date, datetime
from typing import Dict, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.leave_period import LeaveType
from app.infrastructure.repositories.work_repo import WorkSessionRepository
from app.infrastructure.repositories.break_repo import BreakRepository
from app.infrastructure.repositories.leave_repo import LeaveRepository
from app.infrastructure.redis.status_cache import StatusCache


class StatusService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.work_repo = WorkSessionRepository(db)
        self.break_repo = BreakRepository(db)
        self.leave_repo = LeaveRepository(db)
        self.status_cache = StatusCache()
    
    async def get_current_status(self, user_id: int) -> Dict:
        """Get current user status."""
        # Try to get from cache first
        cached_status = await self.status_cache.get_user_status(user_id)
        if cached_status:
            return cached_status
        
        # Get status from database
        status = {
            "work": False,
            "break": False,
            "leave": False,
            "leave_type": None
        }
        
        # Check for active work session
        active_work = await self.work_repo.get_active_by_user_id(user_id)
        if active_work:
            status["work"] = True
            
            # Check for active break session
            active_break = await self.break_repo.get_active_by_user_id(user_id)
            if active_break:
                status["break"] = True
        
        # Check for active leave periods
        active_leaves = await self.leave_repo.get_active_by_user_id(user_id)
        if active_leaves:
            status["leave"] = True
            status["leave_type"] = active_leaves[0].type
        
        # Cache the status
        await self.status_cache.set_user_status(user_id, status)
        
        return status
    
    async def get_daily_summary(self, user_id: int, day: date) -> Dict:
        """Get daily work summary."""
        # Get work sessions for the day
        work_sessions = await self.work_repo.get_by_user_id_and_date(user_id, day)
        
        # Calculate total work time
        total_work_seconds = 0
        total_break_seconds = 0
        
        for session in work_sessions:
            if session.end:
                # Calculate work duration
                work_duration = (session.end - session.start).total_seconds()
                total_work_seconds += work_duration
                
                # Calculate break duration
                breaks = await self.break_repo.get_by_work_session_id(session.id)
                for break_session in breaks:
                    if break_session.end:
                        break_duration = (break_session.end - break_session.start).total_seconds()
                        total_break_seconds += break_duration
        
        # Calculate effective work time
        effective_work_seconds = total_work_seconds - total_break_seconds
        
        # Convert to hours and minutes
        def seconds_to_time(seconds):
            hours, remainder = divmod(int(seconds), 3600)
            minutes = remainder // 60
            return f"{hours}h {minutes}m"
        
        return {
            "date": day.isoformat(),
            "total_work_time": seconds_to_time(total_work_seconds),
            "total_break_time": seconds_to_time(total_break_seconds),
            "effective_work_time": seconds_to_time(effective_work_seconds),
            "work_sessions": len(work_sessions)
        }