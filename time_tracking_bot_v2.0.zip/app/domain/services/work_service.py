from datetime import datetime
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.events.work import WorkStartedEvent, WorkEndedEvent, TimeEditedEvent
from app.domain.models.work_session import WorkSession, WorkLocation
from app.domain.dto.work import WorkStartRequest, WorkEditRequest
from app.infrastructure.repositories.work_repo import WorkSessionRepository
from app.infrastructure.repositories.break_repo import BreakRepository
from app.infrastructure.redis.status_cache import StatusCache


class WorkSessionService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.work_repo = WorkSessionRepository(db)
        self.break_repo = BreakRepository(db)
        self.status_cache = StatusCache()
    
    async def start_work(
        self,
        user_id: int,
        location: str,
        start_time: Optional[datetime] = None
    ) -> WorkSession:
        """Start a work session."""
        # Check if user already has an active work session
        active_session = await self.work_repo.get_active_by_user_id(user_id)
        if active_session:
            raise ValueError("User already has an active work session")
        
        # Validate location
        if location not in [loc.value for loc in WorkLocation]:
            raise ValueError(f"Invalid location: {location}")
        
        # Create work session
        if start_time is None:
            start_time = datetime.utcnow()
        
        work_session = await self.work_repo.create({
            "user_id": user_id,
            "start": start_time,
            "location": location
        })
        
        # Update cache
        await self.status_cache.set_user_status(user_id, {
            "work": True,
            "break": False,
            "leave": False
        })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            WorkStartedEvent(
                user_id=user_id,
                session_id=work_session.id,
                start_time=start_time,
                location=location,
                timestamp=datetime.utcnow()
            )
        )
        
        return work_session
    
    async def end_work(self, user_id: int) -> WorkSession:
        """End the current work session."""
        # Get active work session
        active_session = await self.work_repo.get_active_by_user_id(user_id)
        if not active_session:
            raise ValueError("No active work session")
        
        # End any active break session
        active_break = await self.break_repo.get_active_by_user_id(user_id)
        if active_break:
            from app.domain.services.break_service import BreakService
            break_service = BreakService(self.db)
            await break_service.end_break(user_id)
        
        # End work session
        end_time = datetime.utcnow()
        work_session = await self.work_repo.update(
            active_session.id,
            {"end": end_time}
        )
        
        # Update cache
        await self.status_cache.set_user_status(user_id, {
            "work": False,
            "break": False,
            "leave": False
        })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            WorkEndedEvent(
                user_id=user_id,
                session_id=work_session.id,
                end_time=end_time,
                timestamp=datetime.utcnow()
            )
        )
        
        return work_session
    
    async def edit_work_session(
        self,
        session_id: int,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> WorkSession:
        """Edit a work session."""
        # Get work session
        work_session = await self.work_repo.get_by_id(session_id)
        if not work_session:
            raise ValueError("Work session not found")
        
        # Store old values for event
        old_start = work_session.start
        old_end = work_session.end
        
        # Update work session
        update_data = {}
        if start_time is not None:
            update_data["start"] = start_time
        if end_time is not None:
            update_data["end"] = end_time
        
        work_session = await self.work_repo.update(session_id, update_data)
        
        # Update cache if session is active
        if work_session.end is None:
            await self.status_cache.set_user_status(work_session.user_id, {
                "work": True,
                "break": False,
                "leave": False
            })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            TimeEditedEvent(
                user_id=work_session.user_id,
                session_id=session_id,
                entity_type="work",
                old_start=old_start,
                new_start=start_time or old_start,
                old_end=old_end,
                new_end=end_time or old_end,
                timestamp=datetime.utcnow()
            )
        )
        
        return work_session