from datetime import datetime
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.events.work import UserRegisteredEvent
from app.domain.models.user import User, UserRole
from app.domain.dto.user import UserCreate, UserUpdate
from app.infrastructure.repositories.user_repo import UserRepository
from app.infrastructure.redis.status_cache import StatusCache


class UserService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.user_repo = UserRepository(db)
        self.status_cache = StatusCache()
    
    async def get_by_id(self, user_id: int) -> Optional[User]:
        """Get user by ID."""
        return await self.user_repo.get_by_id(user_id)
    
    async def get_by_telegram_id(self, telegram_id: str) -> Optional[User]:
        """Get user by Telegram ID."""
        return await self.user_repo.get_by_telegram_id(telegram_id)
    
    async def get_or_create_user(
        self,
        telegram_id: str,
        first_name: str,
        last_name: Optional[str] = None,
        username: Optional[str] = None
    ) -> User:
        """Get existing user or create a new one."""
        user = await self.user_repo.get_by_telegram_id(telegram_id)
        
        if user is None:
            # Create new user
            user_data = UserCreate(
                telegram_id=telegram_id,
                first_name=first_name,
                last_name=last_name,
                username=username
            )
            user = await self.user_repo.create(user_data)
            
            # Publish event
            from app.domain.events.base import event_bus
            await event_bus.publish(
                UserRegisteredEvent(
                    user_id=user.id,
                    telegram_id=telegram_id,
                    first_name=first_name,
                    last_name=last_name,
                    username=username,
                    timestamp=datetime.utcnow()
                )
            )
        else:
            # Update user info if needed
            if user.first_name != first_name or user.last_name != last_name or user.username != username:
                update_data = UserUpdate(
                    first_name=first_name,
                    last_name=last_name,
                    username=username
                )
                user = await self.user_repo.update(user.id, update_data)
        
        return user
    
    async def update_user(self, user_id: int, update_data: UserUpdate) -> Optional[User]:
        """Update user information."""
        user = await self.user_repo.update(user_id, update_data)
        if user:
            # Clear cache
            await self.status_cache.clear_user_status(user_id)
        return user
    
    async def update_role(self, user_id: int, is_admin: bool) -> Optional[User]:
        """Update user role."""
        role = UserRole.ADMIN if is_admin else UserRole.USER
        user = await self.user_repo.update_role(user_id, role)
        if user:
            # Clear cache
            await self.status_cache.clear_user_status(user_id)
        return user
    
    async def update_status(self, user_id: int, is_active: bool) -> Optional[User]:
        """Update user status."""
        user = await self.user_repo.update_status(user_id, is_active)
        if user:
            # Clear cache
            await self.status_cache.clear_user_status(user_id)
        return user
    
    async def ban_user(self, user_id: int) -> Optional[User]:
        """Ban user."""
        user = await self.user_repo.ban_user(user_id)
        if user:
            # Clear cache
            await self.status_cache.clear_user_status(user_id)
        return user
    
    async def unban_user(self, user_id: int) -> Optional[User]:
        """Unban user."""
        user = await self.user_repo.unban_user(user_id)
        if user:
            # Clear cache
            await self.status_cache.clear_user_status(user_id)
        return user