import asyncio
from datetime import datetime
from typing import Dict, List, Optional

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.date import DateTrigger
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.events.reminder import ReminderCreatedEvent, ReminderSentEvent
from app.domain.models.reminder import Reminder
from app.domain.dto.reminder import ReminderCreateRequest
from app.infrastructure.repositories.reminder_repo import ReminderRepository
from app.infrastructure.notifications.telegram import TelegramChannel
from app.infrastructure.repositories.user_repo import UserRepository


class ReminderService:
    _instance = None
    _scheduler = None
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._scheduler = AsyncIOScheduler()
        return cls._instance
    
    def __init__(self, db: AsyncSession):
        if not hasattr(self, 'initialized'):
            self.db = db
            self.reminder_repo = ReminderRepository(db)
            self.user_repo = UserRepository(db)
            self.telegram_channel = TelegramChannel()
            self.initialized = True
    
    async def start_scheduler(self):
        """Start the scheduler."""
        if not self._scheduler.running:
            self._scheduler.start()
            
            # Schedule pending reminders
            await self.schedule_pending_reminders()
    
    async def stop_scheduler(self):
        """Stop the scheduler."""
        if self._scheduler.running:
            self._scheduler.shutdown()
    
    async def create_reminder(
        self,
        user_id: int,
        time: datetime,
        message: str
    ) -> Reminder:
        """Create a reminder."""
        # Create reminder in database
        reminder = await self.reminder_repo.create({
            "user_id": user_id,
            "time": time,
            "message": message
        })
        
        # Schedule the reminder
        await self.schedule_reminder(reminder)
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            ReminderCreatedEvent(
                user_id=user_id,
                reminder_id=reminder.id,
                time=time,
                message=message,
                timestamp=datetime.utcnow()
            )
        )
        
        return reminder
    
    async def schedule_reminder(self, reminder: Reminder):
        """Schedule a reminder."""
        # Get user
        user = await self.user_repo.get_by_id(reminder.user_id)
        if not user:
            return
        
        # Schedule job
        job_id = f"reminder_{reminder.id}"
        self._scheduler.add_job(
            self.send_reminder,
            trigger=DateTrigger(run_date=reminder.time),
            args=[reminder.id, user.telegram_id],
            id=job_id,
            replace_existing=True
        )
    
    async def schedule_pending_reminders(self):
        """Schedule all pending reminders."""
        # Get all unsent reminders
        reminders = await self.reminder_repo.get_unsent()
        
        # Schedule each reminder
        for reminder in reminders:
            await self.schedule_reminder(reminder)
    
    async def send_reminder(self, reminder_id: int, telegram_id: str):
        """Send a reminder."""
        # Get reminder
        reminder = await self.reminder_repo.get_by_id(reminder_id)
        if not reminder or reminder.is_sent:
            return
        
        # Send notification
        await self.telegram_channel.send_notification(
            user_id=telegram_id,
            message=reminder.message
        )
        
        # Mark as sent
        await self.reminder_repo.update(reminder_id, {"is_sent": True})
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            ReminderSentEvent(
                user_id=reminder.user_id,
                reminder_id=reminder_id,
                timestamp=datetime.utcnow()
            )
        )
    
    async def delete_reminder(self, reminder_id: int):
        """Delete a reminder."""
        # Get reminder
        reminder = await self.reminder_repo.get_by_id(reminder_id)
        if not reminder:
            return
        
        # Remove from scheduler
        job_id = f"reminder_{reminder_id}"
        if self._scheduler.get_job(job_id):
            self._scheduler.remove_job(job_id)
        
        # Delete from database
        await self.reminder_repo.delete(reminder_id)