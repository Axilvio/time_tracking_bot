from datetime import date, datetime
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.events.leave import LeaveStartedEvent, LeaveEndedEvent, TimeEditedEvent
from app.domain.models.leave_period import LeavePeriod, LeaveType
from app.domain.dto.leave import LeaveEditRequest
from app.infrastructure.repositories.leave_repo import LeaveRepository
from app.infrastructure.redis.status_cache import StatusCache


class LeaveService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.leave_repo = LeaveRepository(db)
        self.status_cache = StatusCache()
    
    async def start_leave(
        self,
        user_id: int,
        leave_type: str,
        start_date: date,
        end_date: Optional[date] = None,
        reason: Optional[str] = None
    ) -> LeavePeriod:
        """Start a leave period."""
        # Validate leave type
        if leave_type not in [lt.value for lt in LeaveType]:
            raise ValueError(f"Invalid leave type: {leave_type}")
        
        # Check for overlapping leave periods
        overlapping = await self.leave_repo.get_overlapping_periods(
            user_id=user_id,
            start_date=start_date,
            end_date=end_date
        )
        if overlapping:
            raise ValueError("Leave period overlaps with existing leave")
        
        # Create leave period
        leave_period = await self.leave_repo.create({
            "user_id": user_id,
            "type": leave_type,
            "start": start_date,
            "end": end_date,
            "reason": reason
        })
        
        # Update cache
        await self.status_cache.set_user_status(user_id, {
            "work": False,
            "break": False,
            "leave": True,
            "leave_type": leave_type
        })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            LeaveStartedEvent(
                user_id=user_id,
                period_id=leave_period.id,
                leave_type=leave_type,
                start_date=start_date,
                end_date=end_date,
                reason=reason,
                timestamp=datetime.utcnow()
            )
        )
        
        return leave_period
    
    async def end_leave(
        self,
        user_id: int,
        leave_type: str,
        end_date: date
    ) -> LeavePeriod:
        """End a leave period."""
        # Get active leave period
        active_leave = await self.leave_repo.get_active_by_user_id_and_type(
            user_id=user_id,
            leave_type=leave_type
        )
        if not active_leave:
            raise ValueError(f"No active {leave_type} leave period")
        
        # Update leave period
        leave_period = await self.leave_repo.update(
            active_leave.id,
            {"end": end_date}
        )
        
        # Update cache
        await self.status_cache.set_user_status(user_id, {
            "work": False,
            "break": False,
            "leave": False
        })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            LeaveEndedEvent(
                user_id=user_id,
                period_id=leave_period.id,
                leave_type=leave_type,
                end_date=end_date,
                timestamp=datetime.utcnow()
            )
        )
        
        return leave_period
    
    async def edit_leave_period(
        self,
        period_id: int,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        reason: Optional[str] = None
    ) -> LeavePeriod:
        """Edit a leave period."""
        # Get leave period
        leave_period = await self.leave_repo.get_by_id(period_id)
        if not leave_period:
            raise ValueError("Leave period not found")
        
        # Store old values for event
        old_start = leave_period.start
        old_end = leave_period.end
        old_reason = leave_period.reason
        
        # Update leave period
        update_data = {}
        if start_date is not None:
            update_data["start"] = start_date
        if end_date is not None:
            update_data["end"] = end_date
        if reason is not None:
            update_data["reason"] = reason
        
        leave_period = await self.leave_repo.update(period_id, update_data)
        
        # Update cache if period is active
        if leave_period.is_active:
            await self.status_cache.set_user_status(leave_period.user_id, {
                "work": False,
                "break": False,
                "leave": True,
                "leave_type": leave_period.type
            })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            TimeEditedEvent(
                user_id=leave_period.user_id,
                session_id=period_id,
                entity_type="leave",
                old_start=old_start,
                new_start=start_date or old_start,
                old_end=old_end,
                new_end=end_date or old_end,
                timestamp=datetime.utcnow()
            )
        )
        
        return leave_period