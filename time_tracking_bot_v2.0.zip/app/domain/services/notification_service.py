from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.user import User
from app.infrastructure.repositories.user_repo import UserRepository
from app.infrastructure.notifications.dispatcher import NotificationDispatcher


class NotificationService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.user_repo = UserRepository(db)
        self.notification_dispatcher = NotificationDispatcher()
    
    async def send_notification_to_users(
        self,
        message: str,
        user_ids: Optional[List[int]] = None
    ):
        """Send notification to users."""
        if user_ids is None:
            # Send to all active users
            users = await self.user_repo.get_active_users()
        else:
            # Send to specific users
            users = []
            for user_id in user_ids:
                user = await self.user_repo.get_by_id(user_id)
                if user and user.is_active:
                    users.append(user)
        
        # Send notifications
        for user in users:
            await self.notification_dispatcher.send_notification(
                user_id=user.telegram_id,
                message=message
            )