from datetime import datetime
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.events import BreakStartedEvent, BreakEndedEvent, TimeEditedEvent
from app.domain.models.break_session import BreakSession
from app.domain.dto import BreakEditRequest
from app.infrastructure.repositories.break_repo import BreakRepository
from app.infrastructure.repositories.work_repo import WorkSessionRepository
from app.infrastructure.redis.status_cache import StatusCache


class BreakService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.break_repo = BreakRepository(db)
        self.work_repo = WorkSessionRepository(db)
        self.status_cache = StatusCache()
    
    async def start_break(self, user_id: int) -> BreakSession:
        """Start a break session."""
        # Check if user has an active work session
        active_work = await self.work_repo.get_active_by_user_id(user_id)
        if not active_work:
            raise ValueError("No active work session")
        
        # Check if user already has an active break session
        active_break = await self.break_repo.get_active_by_user_id(user_id)
        if active_break:
            raise ValueError("User already has an active break session")
        
        # Create break session
        start_time = datetime.utcnow()
        break_session = await self.break_repo.create({
            "work_session_id": active_work.id,
            "user_id": user_id,
            "start": start_time
        })
        
        # Update cache
        await self.status_cache.set_user_status(user_id, {
            "work": True,
            "break": True,
            "leave": False
        })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            BreakStartedEvent(
                user_id=user_id,
                session_id=break_session.id,
                work_session_id=active_work.id,
                start_time=start_time,
                timestamp=datetime.utcnow()
            )
        )
        
        return break_session
    
    async def end_break(self, user_id: int) -> BreakSession:
        """End the current break session."""
        # Get active break session
        active_break = await self.break_repo.get_active_by_user_id(user_id)
        if not active_break:
            raise ValueError("No active break session")
        
        # End break session
        end_time = datetime.utcnow()
        break_session = await self.break_repo.update(
            active_break.id,
            {"end": end_time}
        )
        
        # Update cache
        await self.status_cache.set_user_status(user_id, {
            "work": True,
            "break": False,
            "leave": False
        })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            BreakEndedEvent(
                user_id=user_id,
                session_id=break_session.id,
                work_session_id=break_session.work_session_id,
                end_time=end_time,
                timestamp=datetime.utcnow()
            )
        )
        
        return break_session
    
    async def edit_break_session(
        self,
        session_id: int,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> BreakSession:
        """Edit a break session."""
        # Get break session
        break_session = await self.break_repo.get_by_id(session_id)
        if not break_session:
            raise ValueError("Break session not found")
        
        # Store old values for event
        old_start = break_session.start
        old_end = break_session.end
        
        # Update break session
        update_data = {}
        if start_time is not None:
            update_data["start"] = start_time
        if end_time is not None:
            update_data["end"] = end_time
        
        break_session = await self.break_repo.update(session_id, update_data)
        
        # Update cache if session is active
        if break_session.end is None:
            await self.status_cache.set_user_status(break_session.user_id, {
                "work": True,
                "break": True,
                "leave": False
            })
        
        # Publish event
        from app.domain.events.base import event_bus
        await event_bus.publish(
            TimeEditedEvent(
                user_id=break_session.user_id,
                session_id=session_id,
                entity_type="break",
                old_start=old_start,
                new_start=start_time or old_start,
                old_end=old_end,
                new_end=end_time or old_end,
                timestamp=datetime.utcnow()
            )
        )
        
        return break_session