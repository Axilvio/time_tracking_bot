from datetime import date, datetime
from typing import Dict, List, Optional

from pydantic import BaseModel


class WeeklyStatsResponse(BaseModel):
    week_start: date
    week_end: date
    total_work_time: str
    total_break_time: str
    effective_work_time: str
    work_days: int
    average_work_time: str
    overtime: str
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class MonthlyStatsResponse(BaseModel):
    year: int
    month: int
    total_work_time: str
    total_break_time: str
    effective_work_time: str
    work_days: int
    average_work_time: str
    overtime: str
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class UserStatsResponse(BaseModel):
    user_id: int
    start_date: date
    end_date: date
    total_work_time: str
    total_break_time: str
    effective_work_time: str
    work_days: int
    average_work_time: str
    overtime: str
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class AdminStatsResponse(BaseModel):
    start_date: date
    end_date: date
    total_users: int
    active_users: int
    total_work_time: str
    total_break_time: str
    effective_work_time: str
    average_work_time_per_user: str
    top_performers: List[Dict]
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)


class WorkSessionStatsResponse(BaseModel):
    id: int
    date: date
    start_time: datetime
    end_time: Optional[datetime] = None
    duration: str
    location: str
    break_time: str
    
    @classmethod
    def from_dict(cls, data: Dict):
        return cls(**data)