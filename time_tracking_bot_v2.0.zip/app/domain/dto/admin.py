from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel


class AuditLogResponse(BaseModel):
    id: int
    user_id: Optional[int] = None
    action: str
    details: Optional[Dict] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: datetime
    
    class Config:
        orm_mode = True


class UserManagementResponse(BaseModel):
    id: int
    telegram_id: str
    first_name: str
    last_name: Optional[str] = None
    username: Optional[str] = None
    role: str
    is_active: bool
    is_banned: bool
    timezone: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True


class NotificationRequest(BaseModel):
    message: str
    user_ids: Optional[List[int]] = None  # If None, send to all users