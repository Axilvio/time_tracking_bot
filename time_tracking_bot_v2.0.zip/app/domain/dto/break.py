from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class BreakStartRequest(BaseModel):
    pass


class BreakEditRequest(BaseModel):
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None


class BreakSessionResponse(BaseModel):
    id: int
    work_session_id: int
    user_id: int
    start: datetime
    end: Optional[datetime] = None
    duration: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True