from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class ReminderCreateRequest(BaseModel):
    time: datetime
    message: str


class ReminderResponse(BaseModel):
    id: int
    user_id: int
    time: datetime
    message: str
    is_sent: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True