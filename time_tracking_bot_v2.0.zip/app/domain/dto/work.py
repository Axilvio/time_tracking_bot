from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class WorkStartRequest(BaseModel):
    location: str
    start_time: Optional[datetime] = None


class WorkEditRequest(BaseModel):
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None


class WorkSessionResponse(BaseModel):
    id: int
    user_id: int
    start: datetime
    end: Optional[datetime] = None
    location: str
    notes: Optional[str] = None
    duration: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True