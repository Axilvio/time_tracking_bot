from datetime import date
from typing import Optional

from pydantic import BaseModel


class LeaveStartRequest(BaseModel):
    leave_type: str
    start_date: date
    end_date: Optional[date] = None
    reason: Optional[str] = None


class LeaveEditRequest(BaseModel):
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    reason: Optional[str] = None


class LeavePeriodResponse(BaseModel):
    id: int
    user_id: int
    type: str
    start: date
    end: Optional[date] = None
    reason: Optional[str] = None
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True