from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr


class UserBase(BaseModel):
    telegram_id: str
    first_name: str
    last_name: Optional[str] = None
    username: Optional[str] = None
    timezone: str = "UTC"


class UserCreate(UserBase):
    pass


class UserUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    username: Optional[str] = None
    timezone: Optional[str] = None


class UserResponse(UserBase):
    id: int
    role: str
    is_active: bool
    is_banned: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        orm_mode = True


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str


class UserManagementResponse(UserResponse):
    # Additional fields for admin management
    pass