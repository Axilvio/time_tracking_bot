from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional


@dataclass
class LeaveStartedEvent:
    user_id: int
    period_id: int
    leave_type: str
    start_date: date
    end_date: Optional[date]
    reason: Optional[str]
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "period_id": self.period_id,
            "leave_type": self.leave_type,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "reason": self.reason,
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class LeaveEndedEvent:
    user_id: int
    period_id: int
    leave_type: str
    end_date: date
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "period_id": self.period_id,
            "leave_type": self.leave_type,
            "end_date": self.end_date.isoformat(),
            "timestamp": self.timestamp.isoformat()
        }