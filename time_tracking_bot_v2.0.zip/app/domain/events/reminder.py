from dataclasses import dataclass
from datetime import datetime


@dataclass
class ReminderCreatedEvent:
    user_id: int
    reminder_id: int
    time: datetime
    message: str
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "reminder_id": self.reminder_id,
            "time": self.time.isoformat(),
            "message": self.message,
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class ReminderSentEvent:
    user_id: int
    reminder_id: int
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "reminder_id": self.reminder_id,
            "timestamp": self.timestamp.isoformat()
        }