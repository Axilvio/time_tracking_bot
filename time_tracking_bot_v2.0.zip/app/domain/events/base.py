import asyncio
from typing import Dict, List, Optional
from fastapi import WebSocket

from app.domain.events.handlers import (
    handle_work_started, handle_work_ended, handle_break_started,
    handle_break_ended, handle_leave_started, handle_leave_ended,
    handle_time_edited, handle_reminder_created, handle_reminder_sent,
    handle_user_registered
)


class EventBus:
    _instance = None
    _connections: Dict[int, List[WebSocket]] = {}
    _handlers = {}
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._setup_handlers()
        return cls._instance
    
    def _setup_handlers(self):
        """Setup event handlers."""
        self._handlers = {
            "WorkStartedEvent": [handle_work_started],
            "WorkEndedEvent": [handle_work_ended],
            "BreakStartedEvent": [handle_break_started],
            "BreakEndedEvent": [handle_break_ended],
            "LeaveStartedEvent": [handle_leave_started],
            "LeaveEndedEvent": [handle_leave_ended],
            "TimeEditedEvent": [handle_time_edited],
            "ReminderCreatedEvent": [handle_reminder_created],
            "ReminderSentEvent": [handle_reminder_sent],
            "UserRegisteredEvent": [handle_user_registered]
        }
    
    async def publish(self, event):
        """Publish an event."""
        event_type = event.__class__.__name__
        handlers = self._handlers.get(event_type, [])
        
        # Execute handlers
        for handler in handlers:
            await handler(event)
        
        # Send WebSocket notification
        await self.send_websocket_notification(event)
    
    async def add_connection(self, user_id: int, websocket: WebSocket):
        """Add a WebSocket connection."""
        if user_id not in self._connections:
            self._connections[user_id] = []
        self._connections[user_id].append(websocket)
    
    async def remove_connection(self, user_id: int, websocket: WebSocket):
        """Remove a WebSocket connection."""
        if user_id in self._connections:
            try:
                self._connections[user_id].remove(websocket)
                if not self._connections[user_id]:
                    del self._connections[user_id]
            except ValueError:
                pass
    
    async def send_websocket_notification(self, event):
        """Send WebSocket notification for an event."""
        user_id = getattr(event, "user_id", None)
        if user_id is None:
            return
        
        if user_id in self._connections:
            message = {
                "type": event.__class__.__name__,
                "data": event.dict()
            }
            
            # Send to all connections for the user
            for websocket in self._connections[user_id]:
                try:
                    await websocket.send_json(message)
                except Exception:
                    # Connection might be closed, remove it
                    await self.remove_connection(user_id, websocket)


# Create a singleton instance
event_bus = EventBus()