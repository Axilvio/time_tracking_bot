from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class WorkStartedEvent:
    user_id: int
    session_id: int
    start_time: datetime
    location: str
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "start_time": self.start_time.isoformat(),
            "location": self.location,
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class WorkEndedEvent:
    user_id: int
    session_id: int
    end_time: datetime
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "end_time": self.end_time.isoformat(),
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class TimeEditedEvent:
    user_id: int
    session_id: int
    entity_type: str  # "work", "break", or "leave"
    old_start: Optional[datetime]
    new_start: datetime
    old_end: Optional[datetime]
    new_end: Optional[datetime]
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "entity_type": self.entity_type,
            "old_start": self.old_start.isoformat() if self.old_start else None,
            "new_start": self.new_start.isoformat(),
            "old_end": self.old_end.isoformat() if self.old_end else None,
            "new_end": self.new_end.isoformat() if self.new_end else None,
            "timestamp": self.timestamp.isoformat()
        }