from dataclasses import dataclass
from datetime import datetime


@dataclass
class BreakStartedEvent:
    user_id: int
    session_id: int
    work_session_id: int
    start_time: datetime
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "work_session_id": self.work_session_id,
            "start_time": self.start_time.isoformat(),
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class BreakEndedEvent:
    user_id: int
    session_id: int
    work_session_id: int
    end_time: datetime
    timestamp: datetime
    
    def dict(self):
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "work_session_id": self.work_session_id,
            "end_time": self.end_time.isoformat(),
            "timestamp": self.timestamp.isoformat()
        }