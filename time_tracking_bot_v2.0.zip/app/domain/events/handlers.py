import logging
from datetime import datetime
from typing import Dict, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.events.work import WorkStartedEvent, WorkEndedEvent, TimeEditedEvent
from app.domain.events.break import BreakStartedEvent, BreakEndedEvent
from app.domain.events.leave import LeaveStartedEvent, LeaveEndedEvent
from app.domain.events.reminder import ReminderCreatedEvent, ReminderSentEvent
from app.infrastructure.db.session import get_async_session
from app.infrastructure.repositories.audit_repo import AuditRepository
from app.infrastructure.repositories.user_repo import UserRepository
from app.infrastructure.notifications.dispatcher import NotificationDispatcher
from app.settings import settings

logger = logging.getLogger(__name__)


async def handle_work_started(event: WorkStartedEvent):
    """Handle WorkStartedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "work_started",
            "details": {
                "session_id": event.session_id,
                "start_time": event.start_time.isoformat(),
                "location": event.location
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"Work started at {event.start_time.strftime('%H:%M')} ({event.location})"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} started work at {event.start_time.strftime('%H:%M')} ({event.location})"
                )


async def handle_work_ended(event: WorkEndedEvent):
    """Handle WorkEndedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "work_ended",
            "details": {
                "session_id": event.session_id,
                "end_time": event.end_time.isoformat()
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"Work ended at {event.end_time.strftime('%H:%M')}"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} ended work at {event.end_time.strftime('%H:%M')}"
                )


async def handle_break_started(event: BreakStartedEvent):
    """Handle BreakStartedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "break_started",
            "details": {
                "session_id": event.session_id,
                "work_session_id": event.work_session_id,
                "start_time": event.start_time.isoformat()
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"Break started at {event.start_time.strftime('%H:%M')}"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} started a break at {event.start_time.strftime('%H:%M')}"
                )


async def handle_break_ended(event: BreakEndedEvent):
    """Handle BreakEndedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "break_ended",
            "details": {
                "session_id": event.session_id,
                "work_session_id": event.work_session_id,
                "end_time": event.end_time.isoformat()
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"Break ended at {event.end_time.strftime('%H:%M')}"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} ended a break at {event.end_time.strftime('%H:%M')}"
                )


async def handle_leave_started(event: LeaveStartedEvent):
    """Handle LeaveStartedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "leave_started",
            "details": {
                "period_id": event.period_id,
                "leave_type": event.leave_type,
                "start_date": event.start_date.isoformat(),
                "end_date": event.end_date.isoformat() if event.end_date else None,
                "reason": event.reason
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        leave_type_text = {
            "vacation": "vacation",
            "sick_leave": "sick leave",
            "day_off": "day off"
        }.get(event.leave_type, event.leave_type)
        
        end_text = f" to {event.end_date}" if event.end_date else ""
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"{leave_type_text.title()} started from {event.start_date}{end_text}"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} started {leave_type_text} from {event.start_date}{end_text}"
                )


async def handle_leave_ended(event: LeaveEndedEvent):
    """Handle LeaveEndedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "leave_ended",
            "details": {
                "period_id": event.period_id,
                "leave_type": event.leave_type,
                "end_date": event.end_date.isoformat()
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        leave_type_text = {
            "vacation": "vacation",
            "sick_leave": "sick leave",
            "day_off": "day off"
        }.get(event.leave_type, event.leave_type)
        
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"{leave_type_text.title()} ended on {event.end_date}"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} ended {leave_type_text} on {event.end_date}"
                )


async def handle_time_edited(event: TimeEditedEvent):
    """Handle TimeEditedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "time_edited",
            "details": {
                "session_id": event.session_id,
                "entity_type": event.entity_type,
                "old_start": event.old_start.isoformat() if event.old_start else None,
                "new_start": event.new_start.isoformat(),
                "old_end": event.old_end.isoformat() if event.old_end else None,
                "new_end": event.new_end.isoformat() if event.new_end else None
            }
        })
        
        # Send notification
        dispatcher = NotificationDispatcher()
        entity_text = {
            "work": "work session",
            "break": "break session",
            "leave": "leave period"
        }.get(event.entity_type, event.entity_type)
        
        await dispatcher.send_notification(
            user_id=event.user_id,
            message=f"{entity_text.title()} time edited"
        )
        
        # Send to admin chat if configured
        if settings.notification_chat_id:
            user_repo = UserRepository(db)
            user = await user_repo.get_by_id(event.user_id)
            
            if user:
                await dispatcher.send_notification(
                    user_id=settings.notification_chat_id,
                    message=f"{user.first_name} {user.last_name or ''} edited {entity_text} time"
                )


async def handle_reminder_created(event: ReminderCreatedEvent):
    """Handle ReminderCreatedEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "reminder_created",
            "details": {
                "reminder_id": event.reminder_id,
                "time": event.time.isoformat(),
                "message": event.message
            }
        })


async def handle_reminder_sent(event: ReminderSentEvent):
    """Handle ReminderSentEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "reminder_sent",
            "details": {
                "reminder_id": event.reminder_id
            }
        })


async def handle_user_registered(event):
    """Handle UserRegisteredEvent."""
    async with get_async_session() as db:
        # Log to audit
        audit_repo = AuditRepository(db)
        await audit_repo.create({
            "user_id": event.user_id,
            "action": "user_registered",
            "details": {
                "telegram_id": event.telegram_id,
                "first_name": event.first_name,
                "last_name": event.last_name,
                "username": event.username
            }
        })
        
        # Send notification to admin chat if configured
        if settings.notification_chat_id:
            dispatcher = NotificationDispatcher()
            await dispatcher.send_notification(
                user_id=settings.notification_chat_id,
                message=f"New user registered: {event.first_name} {event.last_name or ''} (@{event.username or 'N/A'})"
            )


def setup_event_handlers():
    """Setup all event handlers."""
    # This function is called from main.py to ensure handlers are registered
    # The actual registration happens in app/domain/events/base.py
    pass