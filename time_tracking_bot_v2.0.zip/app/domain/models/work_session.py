from datetime import datetime
from enum import Enum

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.infrastructure.db.base import Base


class WorkLocation(str, Enum):
    OFFICE = "office"
    REMOTE = "remote"
    SITE = "site"


class WorkSession(Base):
    __tablename__ = "work_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    start = Column(DateTime, nullable=False)
    end = Column(DateTime, nullable=True)
    location = Column(String(20), nullable=False)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="work_sessions")
    break_sessions = relationship("BreakSession", back_populates="work_session", cascade="all, delete-orphan")
    
    @property
    def duration(self):
        if self.end is None:
            return None
        return self.end - self.start
    
    @property
    def is_active(self):
        return self.end is None
    
    def __repr__(self):
        return f"<WorkSession(id={self.id}, user_id={self.user_id}, start={self.start}, end={self.end})>"