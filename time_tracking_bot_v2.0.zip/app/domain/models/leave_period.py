from datetime import date, datetime
from enum import Enum

from sqlalchemy import Column, Date, DateTime, ForeignKey, Integer, String

from app.infrastructure.db.base import Base


class LeaveType(str, Enum):
    VACATION = "vacation"
    SICK_LEAVE = "sick_leave"
    DAY_OFF = "day_off"


class LeavePeriod(Base):
    __tablename__ = "leave_periods"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    type = Column(String(20), nullable=False)
    start = Column(Date, nullable=False)
    end = Column(Date, nullable=True)
    reason = Column(String(500), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="leave_periods")
    
    @property
    def is_active(self):
        if self.end is None:
            return True
        today = date.today()
        return self.start <= today <= self.end
    
    def __repr__(self):
        return f"<LeavePeriod(id={self.id}, user_id={self.user_id}, type={self.type}, start={self.start}, end={self.end})>"