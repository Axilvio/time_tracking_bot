from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer

from app.infrastructure.db.base import Base


class BreakSession(Base):
    __tablename__ = "break_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    work_session_id = Column(Integer, ForeignKey("work_sessions.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    start = Column(DateTime, nullable=False)
    end = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    work_session = relationship("WorkSession", back_populates="break_sessions")
    user = relationship("User", back_populates="break_sessions")
    
    @property
    def duration(self):
        if self.end is None:
            return None
        return self.end - self.start
    
    @property
    def is_active(self):
        return self.end is None
    
    def __repr__(self):
        return f"<BreakSession(id={self.id}, work_session_id={self.work_session_id}, start={self.start}, end={self.end})>"