from telegram.ext import Application

from app.telegram_bot.handlers import (
    start, work, breaks, leaves, reminders, admin, callbacks
)
from app.telegram_bot.keyboards.main import get_main_keyboard


async def setup_dispatcher(application: Application):
    """Setup the dispatcher with handlers."""
    # Add handlers
    application.add_handler(start.start_handler)
    application.add_handler(work.work_handlers)
    application.add_handler(breaks.break_handlers)
    application.add_handler(leaves.leave_handlers)
    application.add_handler(reminders.reminder_handlers)
    application.add_handler(admin.admin_handlers)
    application.add_handler(callbacks.callback_query_handler)
    
    # Set up error handler
    application.add_error_handler(error_handler)


async def error_handler(update, context):
    """Log errors caused by Updates."""
    logger.warning(f'Update "{update}" caused error "{context.error}"')