from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton


def get_main_keyboard(is_working: bool = False, is_on_break: bool = False, is_admin: bool = False):
    """Get the main keyboard based on user status."""
    keyboard = []
    
    # Work buttons
    if not is_working:
        keyboard.append([KeyboardButton("Начать работу")])
    else:
        keyboard.append([KeyboardButton("Завершить работу")])
    
    # Break buttons
    if is_working and not is_on_break:
        keyboard.append([KeyboardButton("Начать перерыв")])
    elif is_on_break:
        keyboard.append([KeyboardButton("Завершить перерыв")])
    
    # Leave buttons
    keyboard.append([
        KeyboardButton("Отпуск"),
        KeyboardButton("Больничный"),
        KeyboardButton("Отгул")
    ])
    
    # Other buttons
    keyboard.append([
        KeyboardButton("Напоминания"),
        KeyboardButton("Статистика")
    ])
    
    # Admin button
    if is_admin:
        keyboard.append([KeyboardButton("Админ-панель")])
    
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_location_keyboard():
    """Get keyboard for location selection."""
    keyboard = [
        [
            KeyboardButton("В офисе"),
            KeyboardButton("Удалённо"),
            KeyboardButton("На площадке")
        ],
        [KeyboardButton("Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_leave_type_keyboard():
    """Get keyboard for leave type selection."""
    keyboard = [
        [
            KeyboardButton("Начать отпуск"),
            KeyboardButton("Начать больничный"),
            KeyboardButton("Начать отгул")
        ],
        [KeyboardButton("Отмена")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_admin_keyboard():
    """Get admin keyboard."""
    keyboard = [
        [
            KeyboardButton("Уведомить всех"),
            KeyboardButton("Статистика команды")
        ],
        [
            KeyboardButton("Аудит лог"),
            KeyboardButton("Управление пользователями")
        ],
        [KeyboardButton("Назад")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_cancel_keyboard():
    """Get keyboard with cancel button."""
    keyboard = [[KeyboardButton("Отмена")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def get_work_history_inline_keyboard(work_sessions):
    """Get inline keyboard for work history."""
    keyboard = []
    
    for session in work_sessions:
        date_str = session.start.strftime("%d.%m.%Y")
        start_time = session.start.strftime("%H:%M")
        end_time = session.end.strftime("%H:%M") if session.end else "Не завершено"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{date_str}: {start_time} - {end_time}",
                callback_data=f"work_session_{session.id}"
            )
        ])
    
    return InlineKeyboardMarkup(keyboard)


def get_work_session_inline_keyboard(session_id):
    """Get inline keyboard for work session actions."""
    keyboard = [
        [
            InlineKeyboardButton(
                "Изменить время начала",
                callback_data=f"edit_work_start_{session_id}"
            ),
            InlineKeyboardButton(
                "Изменить время окончания",
                callback_data=f"edit_work_end_{session_id}"
            )
        ],
        [InlineKeyboardButton("Отмена", callback_data="cancel")]
    ]
    
    return InlineKeyboardMarkup(keyboard)