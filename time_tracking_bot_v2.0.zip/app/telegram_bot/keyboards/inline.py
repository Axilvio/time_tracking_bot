from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def get_confirmation_inline_keyboard(action, data):
    """Get inline keyboard for confirmation."""
    keyboard = [
        [
            InlineKeyboardButton(
                "Да",
                callback_data=f"confirm_{action}_{data}"
            ),
            InlineKeyboardButton(
                "Нет",
                callback_data="cancel"
            )
        ]
    ]
    
    return InlineKeyboardMarkup(keyboard)


def get_reminder_inline_keyboard(reminders):
    """Get inline keyboard for reminders."""
    keyboard = []
    
    for reminder in reminders:
        time_str = reminder.time.strftime("%d.%m.%Y %H:%M")
        status = "Отправлено" if reminder.is_sent else "Ожидает"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{time_str} - {status}",
                callback_data=f"reminder_{reminder.id}"
            )
        ])
    
    keyboard.append([InlineKeyboardButton("Добавить напоминание", callback_data="add_reminder")])
    keyboard.append([InlineKeyboardButton("Отмена", callback_data="cancel")])
    
    return InlineKeyboardMarkup(keyboard)


def get_stats_inline_keyboard():
    """Get inline keyboard for statistics."""
    keyboard = [
        [
            InlineKeyboardButton(
                "За неделю",
                callback_data="stats_week"
            ),
            InlineKeyboardButton(
                "За месяц",
                callback_data="stats_month"
            )
        ],
        [
            InlineKeyboardButton(
                "За период",
                callback_data="stats_period"
            )
        ],
        [InlineKeyboardButton("Отмена", callback_data="cancel")]
    ]
    
    return InlineKeyboardMarkup(keyboard)