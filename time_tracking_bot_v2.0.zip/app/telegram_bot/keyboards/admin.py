from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def get_user_management_inline_keyboard(users):
    """Get inline keyboard for user management."""
    keyboard = []
    
    for user in users:
        status = "Активен" if user.is_active else "Неактивен"
        role = "Админ" if user.is_admin else "Пользователь"
        
        keyboard.append([
            InlineKeyboardButton(
                f"{user.first_name} {user.last_name or ''} - {status} - {role}",
                callback_data=f"user_{user.id}"
            )
        ])
    
    return InlineKeyboardMarkup(keyboard)


def get_user_actions_inline_keyboard(user_id):
    """Get inline keyboard for user actions."""
    keyboard = [
        [
            InlineKeyboardButton(
                "Активировать",
                callback_data=f"activate_user_{user_id}"
            ),
            InlineKeyboardButton(
                "Деактивировать",
                callback_data=f"deactivate_user_{user_id}"
            )
        ],
        [
            InlineKeyboardButton(
                "Сделать админом",
                callback_data=f"make_admin_{user_id}"
            ),
            InlineKeyboardButton(
                "Убрать права админа",
                callback_data=f"remove_admin_{user_id}"
            )
        ],
        [InlineKeyboardButton("Отмена", callback_data="cancel")]
    ]
    
    return InlineKeyboardMarkup(keyboard)