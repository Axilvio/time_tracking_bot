from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler, CallbackQueryHandler

from app.telegram_bot.keyboards.main import get_main_keyboard
from app.telegram_bot.keyboards.inline import get_reminder_inline_keyboard
from app.telegram_bot.api_client import APIClient

# Conversation states
AWAITING_REMINDER_TIME = 1
AWAITING_REMINDER_MESSAGE = 2


async def reminders_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle reminders menu request."""
    user = update.effective_user
    
    try:
        # Get reminders from API
        api_client = APIClient()
        reminders = await api_client.get_reminders(user.id)
        
        await update.message.reply_text(
            "Ваши напоминания:",
            reply_markup=get_reminder_inline_keyboard(reminders)
        )
    except Exception as e:
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")


async def add_reminder_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle add reminder request."""
    await update.message.reply_text(
        "Введите дату и время напоминания в формате ДД.ММ.ГГГГ ЧЧ:ММ:",
        reply_markup=get_cancel_keyboard()
    )
    
    return AWAITING_REMINDER_TIME


async def reminder_time_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle reminder time input."""
    time_text = update.message.text
    
    if time_text == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END
    
    try:
        # Parse datetime
        reminder_time = datetime.strptime(time_text, "%d.%m.%Y %H:%M")
        
        # Check if time is in the future
        if reminder_time <= datetime.now():
            await update.message.reply_text(
                "Время напоминания должно быть в будущем!",
                reply_markup=get_cancel_keyboard()
            )
            return AWAITING_REMINDER_TIME
        
        # Store reminder time
        context.user_data["reminder_time"] = reminder_time
        
        # Ask for message
        await update.message.reply_text(
            "Введите текст напоминания:",
            reply_markup=get_cancel_keyboard()
        )
        
        return AWAITING_REMINDER_MESSAGE
    except ValueError:
        await update.message.reply_text(
            "Неверный формат даты и времени. Пожалуйста, используйте формат ДД.ММ.ГГГГ ЧЧ:ММ.",
            reply_markup=get_cancel_keyboard()
        )
        return AWAITING_REMINDER_TIME


async def reminder_message_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle reminder message input."""
    message_text = update.message.text
    
    if message_text == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END
    
    # Get user and reminder time
    user = update.effective_user
    reminder_time = context.user_data["reminder_time"]
    
    try:
        # Create reminder
        api_client = APIClient()
        await api_client.create_reminder(user.id, reminder_time, message_text)
        
        await update.message.reply_text(
            f"Напоминание установлено на {reminder_time.strftime('%d.%m.%Y %H:%M')}!",
            reply_markup=get_main_keyboard()
        )
        
        return ConversationHandler.END
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END


async def delete_reminder_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle delete reminder callback."""
    query = update.callback_query
    await query.answer()
    
    if query.data.startswith("reminder_"):
        reminder_id = int(query.data.split("_")[1])
        
        try:
            # Delete reminder
            api_client = APIClient()
            await api_client.delete_reminder(reminder_id)
            
            await query.edit_message_text("Напоминание удалено!")
        except Exception as e:
            await query.edit_message_text(f"Произошла ошибка: {str(e)}")


def get_cancel_keyboard():
    """Get keyboard with cancel button."""
    from telegram import ReplyKeyboardMarkup, KeyboardButton
    
    keyboard = [[KeyboardButton("Отмена")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


# Create handlers
reminder_handlers = [
    MessageHandler(filters.Regex("^(Напоминания)$"), reminders_menu),
    CallbackQueryHandler(delete_reminder_callback, pattern="^reminder_"),
]

reminder_conversation = ConversationHandler(
    entry_points=[
        CallbackQueryHandler(lambda u, c: add_reminder_start(u, c), pattern="^add_reminder$"),
    ],
    states={
        AWAITING_REMINDER_TIME: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, reminder_time_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
        AWAITING_REMINDER_MESSAGE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, reminder_message_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
    },
    fallbacks=[
        MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
    ],
)