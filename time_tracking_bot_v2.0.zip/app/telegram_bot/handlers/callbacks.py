from telegram import Update
from telegram.ext import ContextTypes, CallbackQueryHandler

from app.telegram_bot.keyboards.main import get_main_keyboard, get_work_session_inline_keyboard
from app.telegram_bot.api_client import APIClient


async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries."""
    query = update.callback_query
    await query.answer()
    
    data = query.data
    
    # Handle work session callbacks
    if data.startswith("work_session_"):
        session_id = int(data.split("_")[2])
        
        try:
            # Get work session details
            api_client = APIClient()
            session = await api_client.get_work_session(session_id)
            
            # Format session details
            details_text = f"Детали рабочей сессии:\n\n"
            details_text += f"Начало: {session.get('start', 'N/A')}\n"
            details_text += f"Окончание: {session.get('end', 'Не завершено')}\n"
            details_text += f"Местоположение: {session.get('location', 'N/A')}\n"
            details_text += f"Продолжительность: {session.get('duration', 'N/A')}\n"
            
            await query.edit_message_text(
                details_text,
                reply_markup=get_work_session_inline_keyboard(session_id)
            )
        except Exception as e:
            await query.edit_message_text(f"Произошла ошибка: {str(e)}")
    
    # Handle edit work session callbacks
    elif data.startswith("edit_work_"):
        parts = data.split("_")
        session_id = int(parts[3])
        field = parts[2]  # "start" or "end"
        
        # This would start a conversation to edit the work session
        # For simplicity, we'll just show a message
        await query.edit_message_text(
            f"Функция редактирования {field} времени будет реализована в следующей версии."
        )
    
    # Handle cancel callback
    elif data == "cancel":
        user = update.effective_user
        
        # Get user status
        api_client = APIClient()
        status = await api_client.get_user_status(user.id)
        
        # Get user info
        user_info = await api_client.get_user_info(user.id)
        is_admin = user_info.get("is_admin", False) if user_info else False
        
        await query.edit_message_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard(
                is_working=status.get("work", False),
                is_on_break=status.get("break", False),
                is_admin=is_admin
            )
        )
    
    # Handle stats callbacks
    elif data.startswith("stats_"):
        period = data.split("_")[1]  # "week", "month", or "period"
        
        try:
            # Get stats from API
            api_client = APIClient()
            user = update.effective_user
            
            if period == "week":
                stats = await api_client.get_weekly_stats(user.id)
            elif period == "month":
                stats = await api_client.get_monthly_stats(user.id)
            else:
                # For "period", we would need to ask for date range
                # For simplicity, we'll just show a message
                await query.edit_message_text(
                    "Функция статистики за период будет реализована в следующей версии."
                )
                return
            
            # Format stats message
            stats_text = f"Статистика за {period}:\n\n"
            stats_text += f"Общее время работы: {stats.get('total_work_time', '0h 0m')}\n"
            stats_text += f"Общее время перерывов: {stats.get('total_break_time', '0h 0m')}\n"
            stats_text += f"Эффективное время работы: {stats.get('effective_work_time', '0h 0m')}\n"
            stats_text += f"Рабочих дней: {stats.get('work_days', 0)}\n"
            stats_text += f"Среднее время работы: {stats.get('average_work_time', '0h 0m')}\n"
            stats_text += f"Переработки: {stats.get('overtime', '0h 0m')}\n"
            
            await query.edit_message_text(stats_text)
        except Exception as e:
            await query.edit_message_text(f"Произошла ошибка: {str(e)}")
    
    # Handle user management callbacks
    elif data.startswith("user_"):
        user_id = int(data.split("_")[1])
        
        try:
            # Get user details
            api_client = APIClient()
            user = await api_client.get_user(user_id)
            
            # Format user details
            details_text = f"Детали пользователя:\n\n"
            details_text += f"ID: {user.get('id', 'N/A')}\n"
            details_text += f"Telegram ID: {user.get('telegram_id', 'N/A')}\n"
            details_text += f"Имя: {user.get('first_name', 'N/A')} {user.get('last_name', '')}\n"
            details_text += f"Username: @{user.get('username', 'N/A')}\n"
            details_text += f"Роль: {user.get('role', 'N/A')}\n"
            details_text += f"Статус: {'Активен' if user.get('is_active') else 'Неактивен'}\n"
            details_text += f"Заблокирован: {'Да' if user.get('is_banned') else 'Нет'}\n"
            
            await query.edit_message_text(
                details_text,
                reply_markup=get_user_actions_inline_keyboard(user_id)
            )
        except Exception as e:
            await query.edit_message_text(f"Произошла ошибка: {str(e)}")
    
    # Handle user action callbacks
    elif data.startswith(("activate_user_", "deactivate_user_", "make_admin_", "remove_admin_")):
        parts = data.split("_")
        action = parts[0] + "_" + parts[1]  # "activate_user", "deactivate_user", etc.
        user_id = int(parts[2])
        
        try:
            # Perform action
            api_client = APIClient()
            
            if action == "activate_user":
                await api_client.update_user_status(user_id, True)
                message = "Пользователь активирован."
            elif action == "deactivate_user":
                await api_client.update_user_status(user_id, False)
                message = "Пользователь деактивирован."
            elif action == "make_admin":
                await api_client.update_user_role(user_id, True)
                message = "Пользователь сделан админом."
            elif action == "remove_admin":
                await api_client.update_user_role(user_id, False)
                message = "Права админа удалены."
            
            await query.edit_message_text(message)
        except Exception as e:
            await query.edit_message_text(f"Произошла ошибка: {str(e)}")


# Create handler
callback_query_handler = CallbackQueryHandler(handle_callback_query)