from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler

from app.telegram_bot.keyboards.main import get_main_keyboard, get_admin_keyboard
from app.telegram_bot.keyboards.admin import get_user_management_inline_keyboard, get_user_actions_inline_keyboard
from app.telegram_bot.api_client import APIClient

# Conversation states
AWAITING_NOTIFICATION_MESSAGE = 1
USER_MANAGEMENT = 2


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin panel request."""
    await update.message.reply_text(
        "Админ-панель:",
        reply_markup=get_admin_keyboard()
    )


async def notify_all_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle notify all request."""
    await update.message.reply_text(
        "Введите сообщение для отправки всем пользователям:",
        reply_markup=get_cancel_keyboard()
    )
    
    return AWAITING_NOTIFICATION_MESSAGE


async def notification_message_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle notification message input."""
    message_text = update.message.text
    
    if message_text == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_admin_keyboard()
        )
        return ConversationHandler.END
    
    try:
        # Send notification
        api_client = APIClient()
        await api_client.send_notification_to_users(message_text)
        
        await update.message.reply_text(
            "Уведомление отправлено!",
            reply_markup=get_admin_keyboard()
        )
        
        return ConversationHandler.END
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_admin_keyboard()
        )
        return ConversationHandler.END


async def team_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle team stats request."""
    try:
        # Get team stats from API
        api_client = APIClient()
        stats = await api_client.get_team_stats()
        
        # Format stats message
        stats_text = "Статистика команды:\n\n"
        stats_text += f"Всего пользователей: {stats.get('total_users', 0)}\n"
        stats_text += f"Активных пользователей: {stats.get('active_users', 0)}\n"
        stats_text += f"Общее время работы: {stats.get('total_work_time', '0h 0m')}\n"
        stats_text += f"Эффективное время работы: {stats.get('effective_work_time', '0h 0m')}\n"
        stats_text += f"Среднее время работы на пользователя: {stats.get('average_work_time_per_user', '0h 0m')}\n"
        
        # Add top performers
        top_performers = stats.get('top_performers', [])
        if top_performers:
            stats_text += "\nТоп performers:\n"
            for i, performer in enumerate(top_performers[:5], 1):
                stats_text += f"{i}. Пользователь {performer.get('user_id')}: {performer.get('total_work_time', '0h 0m')}\n"
        
        await update.message.reply_text(stats_text)
    except Exception as e:
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")


async def audit_logs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle audit logs request."""
    try:
        # Get audit logs from API
        api_client = APIClient()
        logs = await api_client.get_audit_logs()
        
        if not logs:
            await update.message.reply_text("Нет записей в аудите.")
            return
        
        # Format logs message
        logs_text = "Последние записи в аудите:\n\n"
        
        for log in logs[:10]:  # Show only last 10 logs
            user_id = log.get('user_id', 'N/A')
            action = log.get('action', 'N/A')
            timestamp = log.get('created_at', 'N/A')
            
            logs_text += f"Пользователь {user_id}: {action} - {timestamp}\n"
        
        await update.message.reply_text(logs_text)
    except Exception as e:
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")


async def user_management_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle user management request."""
    try:
        # Get users from API
        api_client = APIClient()
        users = await api_client.get_users()
        
        await update.message.reply_text(
            "Управление пользователями:",
            reply_markup=get_user_management_inline_keyboard(users)
        )
        
        return USER_MANAGEMENT
    except Exception as e:
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")


def get_cancel_keyboard():
    """Get keyboard with cancel button."""
    from telegram import ReplyKeyboardMarkup, KeyboardButton
    
    keyboard = [[KeyboardButton("Отмена")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


# Create handlers
admin_handlers = [
    MessageHandler(filters.Regex("^(Админ-панель)$"), admin_panel),
    MessageHandler(filters.Regex("^(Уведомить всех)$"), notify_all_start),
    MessageHandler(filters.Regex("^(Статистика команды)$"), team_stats),
    MessageHandler(filters.Regex("^(Аудит лог)$"), audit_logs),
    MessageHandler(filters.Regex("^(Управление пользователями)$"), user_management_start),
    MessageHandler(filters.Regex("^(Назад)$"), lambda u, c: None),  # Will be handled in main.py
]

notify_all_conversation = ConversationHandler(
    entry_points=[
        MessageHandler(filters.Regex("^(Уведомить всех)$"), notify_all_start),
    ],
    states={
        AWAITING_NOTIFICATION_MESSAGE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, notification_message_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
    },
    fallbacks=[
        MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
    ],
)