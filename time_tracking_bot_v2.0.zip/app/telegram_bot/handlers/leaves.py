from datetime import date, datetime
from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler

from app.telegram_bot.keyboards.main import get_main_keyboard, get_leave_type_keyboard
from app.telegram_bot.api_client import APIClient

# Conversation states
AWAITING_LEAVE_TYPE = 1
AWAITING_LEAVE_START = 2
AWAITING_LEAVE_END = 3


async def leave_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle leave start request."""
    await update.message.reply_text(
        "Какой тип отпуска вы хотите оформить?",
        reply_markup=get_leave_type_keyboard()
    )
    
    return AWAITING_LEAVE_TYPE


async def leave_type_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle leave type selection."""
    leave_type = update.message.text
    
    if leave_type == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END
    
    if leave_type not in ["Начать отпуск", "Начать больничный", "Начать отгул"]:
        await update.message.reply_text(
            "Пожалуйста, выберите один из предложенных вариантов.",
            reply_markup=get_leave_type_keyboard()
        )
        return AWAITING_LEAVE_TYPE
    
    # Store leave type
    context.user_data["leave_type"] = leave_type.lower().replace("начать ", "")
    
    # Ask for start date
    await update.message.reply_text(
        "Введите дату начала в формате ДД.ММ.ГГГГ:",
        reply_markup=get_cancel_keyboard()
    )
    
    return AWAITING_LEAVE_START


async def leave_start_date_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle leave start date."""
    date_text = update.message.text
    
    if date_text == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END
    
    try:
        # Parse date
        start_date = datetime.strptime(date_text, "%d.%m.%Y").date()
        
        # Store start date
        context.user_data["start_date"] = start_date
        
        # Ask for end date
        await update.message.reply_text(
            "Введите дату окончания в формате ДД.ММ.ГГГГ (или оставьте пустым для неопределенного срока):",
            reply_markup=get_cancel_keyboard()
        )
        
        return AWAITING_LEAVE_END
    except ValueError:
        await update.message.reply_text(
            "Неверный формат даты. Пожалуйста, используйте формат ДД.ММ.ГГГГ.",
            reply_markup=get_cancel_keyboard()
        )
        return AWAITING_LEAVE_START


async def leave_end_date_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle leave end date."""
    date_text = update.message.text
    
    if date_text == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END
    
    try:
        # Parse end date if provided
        end_date = None
        if date_text.strip():
            end_date = datetime.strptime(date_text, "%d.%m.%Y").date()
        
        # Get user and leave type
        user = update.effective_user
        leave_type = context.user_data["leave_type"]
        start_date = context.user_data["start_date"]
        
        # Start leave period
        api_client = APIClient()
        await api_client.start_leave(user.id, leave_type, start_date, end_date)
        
        # Format message
        leave_type_text = {
            "отпуск": "отпуск",
            "больничный": "больничный",
            "отгул": "отгул"
        }.get(leave_type, leave_type)
        
        end_text = f" до {end_date}" if end_date else ""
        
        await update.message.reply_text(
            f"{leave_type_text.title()} оформлен с {start_date}{end_text}!",
            reply_markup=get_main_keyboard()
        )
        
        return ConversationHandler.END
    except ValueError:
        await update.message.reply_text(
            "Неверный формат даты. Пожалуйста, используйте формат ДД.ММ.ГГГГ.",
            reply_markup=get_cancel_keyboard()
        )
        return AWAITING_LEAVE_END
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END


def get_cancel_keyboard():
    """Get keyboard with cancel button."""
    from telegram import ReplyKeyboardMarkup, KeyboardButton
    
    keyboard = [[KeyboardButton("Отмена")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


# Create handlers
leave_handlers = [
    MessageHandler(filters.Regex("^(Отпуск|Больничный|Отгул)$"), leave_start),
]

leave_conversation = ConversationHandler(
    entry_points=[
        MessageHandler(filters.Regex("^(Начать отпуск|Начать больничный|Начать отгул)$"), leave_start),
    ],
    states={
        AWAITING_LEAVE_TYPE: [
            MessageHandler(filters.Regex("^(Начать отпуск|Начать больничный|Начать отгул)$"), leave_type_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
        AWAITING_LEAVE_START: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, leave_start_date_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
        AWAITING_LEAVE_END: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, leave_end_date_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
    },
    fallbacks=[
        MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
    ],
)