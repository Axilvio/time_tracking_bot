from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters, ConversationHandler, CallbackQueryHandler

from app.telegram_bot.keyboards.main import get_main_keyboard, get_location_keyboard
from app.telegram_bot.api_client import APIClient

# Conversation states
AWAITING_LOCATION = 1


async def work_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle work start request."""
    user = update.effective_user
    
    # Check if user already has an active work session
    api_client = APIClient()
    status = await api_client.get_user_status(user.id)
    
    if status.get("work"):
        await update.message.reply_text(
            "У вас уже есть активная рабочая сессия!",
            reply_markup=get_main_keyboard(
                is_working=True,
                is_on_break=status.get("break", False)
            )
        )
        return ConversationHandler.END
    
    # Ask for location
    await update.message.reply_text(
        "Где вы начинаете работу?",
        reply_markup=get_location_keyboard()
    )
    
    return AWAITING_LOCATION


async def location_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle location selection."""
    location = update.message.text
    
    if location == "Отмена":
        await update.message.reply_text(
            "Действие отменено.",
            reply_markup=get_main_keyboard()
        )
        return ConversationHandler.END
    
    if location not in ["В офисе", "Удалённо", "На площадке"]:
        await update.message.reply_text(
            "Пожалуйста, выберите одно из предложенных местоположений.",
            reply_markup=get_location_keyboard()
        )
        return AWAITING_LOCATION
    
    # Start work session
    user = update.effective_user
    api_client = APIClient()
    
    try:
        await api_client.start_work(user.id, location.lower().replace("ё", "е"))
        
        await update.message.reply_text(
            f"Работа начата ({location})! Удачного рабочего дня!",
            reply_markup=get_main_keyboard(is_working=True)
        )
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    return ConversationHandler.END


async def work_end(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle work end request."""
    user = update.effective_user
    
    # Check if user has an active work session
    api_client = APIClient()
    status = await api_client.get_user_status(user.id)
    
    if not status.get("work"):
        await update.message.reply_text(
            "У вас нет активной рабочей сессии!",
            reply_markup=get_main_keyboard()
        )
        return
    
    try:
        # End work session
        work_session = await api_client.end_work(user.id)
        
        # Calculate duration
        if work_session.get("duration"):
            await update.message.reply_text(
                f"Работа завершена! Продолжительность: {work_session.get('duration')}",
                reply_markup=get_main_keyboard()
            )
        else:
            await update.message.reply_text(
                "Работа завершена!",
                reply_markup=get_main_keyboard()
            )
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_main_keyboard(is_working=True, is_on_break=status.get("break", False))
        )


async def work_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle work history request."""
    user = update.effective_user
    
    try:
        # Get work history from API
        api_client = APIClient()
        work_sessions = await api_client.get_work_history(user.id)
        
        if not work_sessions:
            await update.message.reply_text("У вас еще нет рабочих сессий.")
            return
        
        # Send work history
        from app.telegram_bot.keyboards.main import get_work_history_inline_keyboard
        await update.message.reply_text(
            "Выберите рабочую сессию для просмотра:",
            reply_markup=get_work_history_inline_keyboard(work_sessions)
        )
    except Exception as e:
        await update.message.reply_text(f"Произошла ошибка: {str(e)}")


# Create handlers
work_handlers = [
    MessageHandler(filters.Regex("^(Начать работу)$"), work_start),
    MessageHandler(filters.Regex("^(Завершить работу)$"), work_end),
    MessageHandler(filters.Regex("^(История работы)$"), work_history),
    MessageHandler(filters.Regex("^(В офисе|Удалённо|На площадке)$"), location_received),
    MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
]

work_conversation = ConversationHandler(
    entry_points=[
        MessageHandler(filters.Regex("^(Начать работу)$"), work_start),
    ],
    states={
        AWAITING_LOCATION: [
            MessageHandler(filters.Regex("^(В офисе|Удалённо|На площадке)$"), location_received),
            MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
        ],
    },
    fallbacks=[
        MessageHandler(filters.Regex("^(Отмена)$"), lambda u, c: ConversationHandler.END),
    ],
)