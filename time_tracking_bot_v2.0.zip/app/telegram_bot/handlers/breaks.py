from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters

from app.telegram_bot.keyboards.main import get_main_keyboard
from app.telegram_bot.api_client import APIClient


async def break_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle break start request."""
    user = update.effective_user
    
    # Check if user has an active work session
    api_client = APIClient()
    status = await api_client.get_user_status(user.id)
    
    if not status.get("work"):
        await update.message.reply_text(
            "У вас нет активной рабочей сессии!",
            reply_markup=get_main_keyboard()
        )
        return
    
    if status.get("break"):
        await update.message.reply_text(
            "У вас уже есть активный перерыв!",
            reply_markup=get_main_keyboard(is_working=True, is_on_break=True)
        )
        return
    
    try:
        # Start break session
        await api_client.start_break(user.id)
        
        await update.message.reply_text(
            "Перерыв начат!",
            reply_markup=get_main_keyboard(is_working=True, is_on_break=True)
        )
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_main_keyboard(is_working=True)
        )


async def break_end(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle break end request."""
    user = update.effective_user
    
    # Check if user has an active break session
    api_client = APIClient()
    status = await api_client.get_user_status(user.id)
    
    if not status.get("break"):
        await update.message.reply_text(
            "У вас нет активного перерыва!",
            reply_markup=get_main_keyboard(is_working=True)
        )
        return
    
    try:
        # End break session
        break_session = await api_client.end_break(user.id)
        
        # Calculate duration
        if break_session.get("duration"):
            await update.message.reply_text(
                f"Перерыв завершен! Продолжительность: {break_session.get('duration')}",
                reply_markup=get_main_keyboard(is_working=True)
            )
        else:
            await update.message.reply_text(
                "Перерыв завершен!",
                reply_markup=get_main_keyboard(is_working=True)
            )
    except Exception as e:
        await update.message.reply_text(
            f"Произошла ошибка: {str(e)}",
            reply_markup=get_main_keyboard(is_working=True, is_on_break=True)
        )


# Create handlers
break_handlers = [
    MessageHandler(filters.Regex("^(Начать перерыв)$"), break_start),
    MessageHandler(filters.Regex("^(Завершить перерыв)$"), break_end),
]