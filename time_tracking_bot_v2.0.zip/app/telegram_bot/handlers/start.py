from telegram import Update
from telegram.ext import ContextTypes, CommandHandler, MessageHandler, filters

from app.telegram_bot.keyboards.main import get_main_keyboard
from app.telegram_bot.api_client import APIClient


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    user = update.effective_user
    
    # Get user status from API
    api_client = APIClient()
    status = await api_client.get_user_status(user.id)
    
    # Get user info from API
    user_info = await api_client.get_user_info(user.id)
    
    # Check if user is admin
    is_admin = user_info.get("is_admin", False) if user_info else False
    
    # Send welcome message
    await update.message.reply_text(
        f"Привет, {user.first_name}! Я бот для учета рабочего времени Arkady v2.",
        reply_markup=get_main_keyboard(
            is_working=status.get("work", False),
            is_on_break=status.get("break", False),
            is_admin=is_admin
        )
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command."""
    help_text = """
    *Команды бота:*
    
    /start - Начать работу с ботом
    /help - Показать это сообщение
    /status - Показать текущий статус
    /stats - Показать статистику
    
    *Основные функции:*
    • Начать/завершить работу
    • Начать/завершить перерыв
    • Оформить отпуск/больничный/отгул
    • Установить напоминания
    • Просмотреть статистику
    
    *Для администраторов:*
    • Отправить уведомление всем пользователям
    • Просмотреть статистику команды
    • Управление пользователями
    """
    
    await update.message.reply_text(help_text, parse_mode="Markdown")


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle status request."""
    user = update.effective_user
    
    # Get user status from API
    api_client = APIClient()
    status = await api_client.get_user_status(user.id)
    
    # Format status message
    status_text = "Ваш текущий статус:\n\n"
    
    if status.get("work"):
        status_text += "🟢 *На работе*\n"
        
        if status.get("break"):
            status_text += "🟡 *На перерыве*\n"
    else:
        status_text += "🔴 *Не на работе*\n"
    
    if status.get("leave"):
        leave_type = status.get("leave_type", "отпуск")
        status_text += f"🏖 *На {leave_type}*\n"
    
    await update.message.reply_text(status_text, parse_mode="Markdown")


# Create handlers
start_handler = CommandHandler("start", start)
help_handler = CommandHandler("help", help_command)
status_handler = CommandHandler("status", status)