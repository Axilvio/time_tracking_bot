import asyncio
import logging
from telegram.ext import Application

from app.telegram_bot.dispatcher import setup_dispatcher
from app.settings import settings

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def main():
    """Start the bot."""
    application = Application.builder().token(settings.bot_token).build()
    
    # Setup dispatcher
    await setup_dispatcher(application)
    
    # Start the Bot
    logger.info("Starting Arkady v2 bot...")
    
    # Run the bot until the user presses Ctrl-C
    await application.run_polling()


if __name__ == "__main__":
    asyncio.run(main())