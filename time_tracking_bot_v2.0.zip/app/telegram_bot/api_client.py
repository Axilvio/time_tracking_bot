import json
import logging
from typing import Dict, List, Optional

import aiohttp
from jose import jwt

from app.settings import settings

logger = logging.getLogger(__name__)


class APIClient:
    """Client for communicating with API."""
    
    def __init__(self):
        self.base_url = "http://backend:8000/api"
        self.token = None
        self.session = None
    
    async def _get_session(self):
        """Get or create aiohttp session."""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session
    
    async def _get_token(self):
        """Get JWT token for API requests."""
        if self.token is None:
            # For bot-to-bot communication, we'll use a special token
            # In production, this should be properly authenticated
            self.token = "bot_internal_token"
        return self.token
    
    async def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict:
        """Make a request to the API."""
        url = f"{self.base_url}/{endpoint}"
        headers = {
            "Authorization": f"Bearer {await self._get_token()}",
            "Content-Type": "application/json"
        }
        
        session = await self._get_session()
        
        try:
            if method == "GET":
                async with session.get(url, headers=headers) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        error_text = await response.text()
                        logger.error(f"API GET error {response.status}: {error_text}")
                        raise Exception(f"API error: {response.status}")
            elif method == "POST":
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status in [200, 201]:
                        return await response.json()
                    else:
                        error_text = await response.text()
                        logger.error(f"API POST error {response.status}: {error_text}")
                        raise Exception(f"API error: {response.status}")
            elif method == "PATCH":
                async with session.patch(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        error_text = await response.text()
                        logger.error(f"API PATCH error {response.status}: {error_text}")
                        raise Exception(f"API error: {response.status}")
            elif method == "DELETE":
                async with session.delete(url, headers=headers) as response:
                    if response.status == 200:
                        return {"success": True}
                    else:
                        error_text = await response.text()
                        logger.error(f"API DELETE error {response.status}: {error_text}")
                        raise Exception(f"API error: {response.status}")
        except aiohttp.ClientError as e:
            logger.error(f"Network error: {e}", exc_info=True)
            raise Exception(f"Network error: {str(e)}")
    
    async def get_user_status(self, telegram_id: int) -> Dict:
        """Get user status."""
        try:
            return await self._make_request("GET", f"status/{telegram_id}")
        except Exception as e:
            logger.error(f"Error getting user status: {e}", exc_info=True)
            return {"work": False, "break": False, "leave": False}
    
    async def get_user_info(self, telegram_id: int) -> Optional[Dict]:
        """Get user info."""
        try:
            return await self._make_request("GET", f"users/{telegram_id}")
        except Exception as e:
            logger.error(f"Error getting user info: {e}", exc_info=True)
            return None
    
    async def start_work(self, telegram_id: int, location: str) -> Dict:
        """Start work session."""
        return await self._make_request("POST", "work/start", {
            "location": location
        })
    
    async def end_work(self, telegram_id: int) -> Dict:
        """End work session."""
        return await self._make_request("POST", "work/end")
    
    async def get_work_history(self, telegram_id: int) -> List[Dict]:
        """Get work history."""
        response = await self._make_request("GET", "work/history")
        return response if isinstance(response, list) else []
    
    async def get_work_session(self, session_id: int) -> Dict:
        """Get work session by ID."""
        return await self._make_request("GET", f"work/{session_id}")
    
    async def start_break(self, telegram_id: int) -> Dict:
        """Start break session."""
        return await self._make_request("POST", "breaks/start")
    
    async def end_break(self, telegram_id: int) -> Dict:
        """End break session."""
        return await self._make_request("POST", "breaks/end")
    
    async def start_leave(
        self,
        telegram_id: int,
        leave_type: str,
        start_date,
        end_date=None
    ) -> Dict:
        """Start leave period."""
        data = {
            "leave_type": leave_type,
            "start_date": start_date.isoformat()
        }
        
        if end_date:
            data["end_date"] = end_date.isoformat()
        
        return await self._make_request("POST", "leaves/start", data)
    
    async def get_reminders(self, telegram_id: int) -> List[Dict]:
        """Get reminders."""
        response = await self._make_request("GET", "reminders")
        return response if isinstance(response, list) else []
    
    async def create_reminder(self, telegram_id: int, time, message: str) -> Dict:
        """Create reminder."""
        return await self._make_request("POST", "reminders/", {
            "time": time.isoformat(),
            "message": message
        })
    
    async def delete_reminder(self, reminder_id: int) -> Dict:
        """Delete reminder."""
        return await self._make_request("DELETE", f"reminders/{reminder_id}")
    
    async def send_notification_to_users(self, message: str, user_ids: Optional[List[int]] = None) -> Dict:
        """Send notification to users."""
        data = {
            "message": message
        }
        
        if user_ids:
            data["user_ids"] = user_ids
        
        return await self._make_request("POST", "admin/notify", data)
    
    async def get_team_stats(self) -> Dict:
        """Get team statistics."""
        from datetime import date, timedelta
        
        # Get stats for the last 30 days
        end_date = date.today()
        start_date = end_date - timedelta(days=30)
        
        return await self._make_request(
            "GET",
            f"admin/overview?start_date={start_date.isoformat()}&end_date={end_date.isoformat()}"
        )
    
    async def get_audit_logs(self) -> List[Dict]:
        """Get audit logs."""
        response = await self._make_request("GET", "admin/audit-logs")
        return response if isinstance(response, list) else []
    
    async def get_users(self) -> List[Dict]:
        """Get all users."""
        response = await self._make_request("GET", "admin/users")
        return response if isinstance(response, list) else []
    
    async def get_user(self, user_id: int) -> Dict:
        """Get user by ID."""
        return await self._make_request("GET", f"admin/users/{user_id}")
    
    async def update_user_status(self, user_id: int, is_active: bool) -> Dict:
        """Update user status."""
        return await self._make_request("PATCH", f"admin/users/{user_id}/status", {
            "is_active": is_active
        })
    
    async def update_user_role(self, user_id: int, is_admin: bool) -> Dict:
        """Update user role."""
        return await self._make_request("PATCH", f"admin/users/{user_id}/role", {
            "is_admin": is_admin
        })
    
    async def get_weekly_stats(self, telegram_id: int) -> Dict:
        """Get weekly statistics."""
        from datetime import date, timedelta
        
        # Get stats for the current week
        today = date.today()
        week_start = today - timedelta(days=today.weekday())
        
        return await self._make_request(
            "GET",
            f"stats/weekly?week_start={week_start.isoformat()}"
        )
    
    async def get_monthly_stats(self, telegram_id: int) -> Dict:
        """Get monthly statistics."""
        from datetime import date
        
        # Get stats for the current month
        today = date.today()
        
        return await self._make_request(
            "GET",
            f"stats/monthly?year={today.year}&month={today.month}"
        )
    
    async def close(self):
        """Close the aiohttp session."""
        if self.session and not self.session.closed:
            await self.session.close()