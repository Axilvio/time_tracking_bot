import json
from typing import Dict, Optional

from app.infrastructure.redis.client import get_redis_client


class StatsCache:
    """Cache for statistics."""
    
    CACHE_KEY_PREFIX = "stats:"
    CACHE_EXPIRE_SECONDS = 3600  # 1 hour
    
    async def get_stats(self, key: str) -> Optional[Dict]:
        """Get stats from cache."""
        redis = await get_redis_client()
        cache_key = f"{self.CACHE_KEY_PREFIX}{key}"
        
        stats_json = await redis.get(cache_key)
        if stats_json:
            return json.loads(stats_json)
        
        return None
    
    async def set_stats(self, key: str, stats: Dict):
        """Set stats in cache."""
        redis = await get_redis_client()
        cache_key = f"{self.CACHE_KEY_PREFIX}{key}"
        
        await redis.setex(
            cache_key,
            self.CACHE_EXPIRE_SECONDS,
            json.dumps(stats)
        )
    
    async def clear_stats(self, key: str):
        """Clear stats from cache."""
        redis = await get_redis_client()
        cache_key = f"{self.CACHE_KEY_PREFIX}{key}"
        
        await redis.delete(cache_key)