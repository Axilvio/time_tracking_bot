import aioredis
from typing import Optional

from app.settings import settings

_redis_client: Optional[aioredis.Redis] = None


async def get_redis_client() -> aioredis.Redis:
    """Get Redis client."""
    global _redis_client
    
    if _redis_client is None:
        _redis_client = aioredis.from_url(settings.redis_url)
    
    return _redis_client


async def init_redis():
    """Initialize Redis."""
    await get_redis_client()