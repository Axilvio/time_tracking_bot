import json
from typing import Dict, Optional

from app.infrastructure.redis.client import get_redis_client


class StatusCache:
    """Cache for user status."""
    
    CACHE_KEY_PREFIX = "user_status:"
    CACHE_EXPIRE_SECONDS = 300  # 5 minutes
    
    async def get_user_status(self, user_id: int) -> Optional[Dict]:
        """Get user status from cache."""
        redis = await get_redis_client()
        key = f"{self.CACHE_KEY_PREFIX}{user_id}"
        
        status_json = await redis.get(key)
        if status_json:
            return json.loads(status_json)
        
        return None
    
    async def set_user_status(self, user_id: int, status: Dict):
        """Set user status in cache."""
        redis = await get_redis_client()
        key = f"{self.CACHE_KEY_PREFIX}{user_id}"
        
        await redis.setex(
            key,
            self.CACHE_EXPIRE_SECONDS,
            json.dumps(status)
        )
    
    async def clear_user_status(self, user_id: int):
        """Clear user status from cache."""
        redis = await get_redis_client()
        key = f"{self.CACHE_KEY_PREFIX}{user_id}"
        
        await redis.delete(key)