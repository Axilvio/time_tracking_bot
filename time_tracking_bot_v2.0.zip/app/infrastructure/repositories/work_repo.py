from datetime import date, datetime
from typing import List, Optional

from sqlalchemy import select, and_, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.work_session import WorkSession


class WorkSessionRepository:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, work_data: dict) -> WorkSession:
        """Create a new work session."""
        work_session = WorkSession(**work_data)
        self.db.add(work_session)
        await self.db.commit()
        await self.db.refresh(work_session)
        return work_session
    
    async def get_by_id(self, session_id: int) -> Optional[WorkSession]:
        """Get work session by ID."""
        result = await self.db.execute(
            select(WorkSession).where(WorkSession.id == session_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_user_id(self, user_id: int, skip: int = 0, limit: int = 100) -> List[WorkSession]:
        """Get work sessions by user ID."""
        result = await self.db.execute(
            select(WorkSession)
            .where(WorkSession.user_id == user_id)
            .order_by(desc(WorkSession.start))
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_active_by_user_id(self, user_id: int) -> Optional[WorkSession]:
        """Get active work session by user ID."""
        result = await self.db.execute(
            select(WorkSession)
            .where(and_(
                WorkSession.user_id == user_id,
                WorkSession.end.is_(None)
            ))
        )
        return result.scalar_one_or_none()
    
    async def get_by_user_id_and_date(self, user_id: int, day: date) -> List[WorkSession]:
        """Get work sessions by user ID and date."""
        start_of_day = datetime.combine(day, datetime.min.time())
        end_of_day = datetime.combine(day, datetime.max.time())
        
        result = await self.db.execute(
            select(WorkSession)
            .where(and_(
                WorkSession.user_id == user_id,
                WorkSession.start >= start_of_day,
                WorkSession.start <= end_of_day
            ))
        )
        return result.scalars().all()
    
    async def get_by_user_id_and_date_range(
        self,
        user_id: int,
        start_date: date,
        end_date: date
    ) -> List[WorkSession]:
        """Get work sessions by user ID and date range."""
        start_of_day = datetime.combine(start_date, datetime.min.time())
        end_of_day = datetime.combine(end_date, datetime.max.time())
        
        result = await self.db.execute(
            select(WorkSession)
            .where(and_(
                WorkSession.user_id == user_id,
                WorkSession.start >= start_of_day,
                WorkSession.start <= end_of_day
            ))
        )
        return result.scalars().all()
    
    async def get_by_date_range(self, start_date: date, end_date: date) -> List[WorkSession]:
        """Get work sessions by date range."""
        start_of_day = datetime.combine(start_date, datetime.min.time())
        end_of_day = datetime.combine(end_date, datetime.max.time())
        
        result = await self.db.execute(
            select(WorkSession)
            .where(and_(
                WorkSession.start >= start_of_day,
                WorkSession.start <= end_of_day
            ))
        )
        return result.scalars().all()
    
    async def update(self, session_id: int, update_data: dict) -> Optional[WorkSession]:
        """Update work session."""
        work_session = await self.get_by_id(session_id)
        if not work_session:
            return None
        
        for field, value in update_data.items():
            setattr(work_session, field, value)
        
        await self.db.commit()
        await self.db.refresh(work_session)
        return work_session
    
    async def count_unique_users_in_date_range(self, start_date: date, end_date: date) -> int:
        """Count unique users with work sessions in date range."""
        start_of_day = datetime.combine(start_date, datetime.min.time())
        end_of_day = datetime.combine(end_date, datetime.max.time())
        
        result = await self.db.execute(
            select(func.count(func.distinct(WorkSession.user_id)))
            .where(and_(
                WorkSession.start >= start_of_day,
                WorkSession.start <= end_of_day
            ))
        )
        return result.scalar()
    
    async def get_top_performers(self, start_date: date, end_date: date, limit: int = 10) -> List[dict]:
        """Get top performers by effective work time."""
        start_of_day = datetime.combine(start_date, datetime.min.time())
        end_of_day = datetime.combine(end_date, datetime.max.time())
        
        # This is a simplified query - in a real implementation, you might need to
        # calculate effective work time (work time - break time) using a more complex query
        result = await self.db.execute(
            select(
                WorkSession.user_id,
                func.sum(func.extract('epoch', WorkSession.end - WorkSession.start)).label('total_seconds')
            )
            .where(and_(
                WorkSession.start >= start_of_day,
                WorkSession.start <= end_of_day,
                WorkSession.end.isnot(None)
            ))
            .group_by(WorkSession.user_id)
            .order_by(desc('total_seconds'))
            .limit(limit)
        )
        
        # Convert to list of dicts
        performers = []
        for row in result:
            total_seconds = row.total_seconds or 0
            hours, remainder = divmod(int(total_seconds), 3600)
            minutes = remainder // 60
            
            performers.append({
                "user_id": row.user_id,
                "total_work_time": f"{hours}h {minutes}m"
            })
        
        return performers