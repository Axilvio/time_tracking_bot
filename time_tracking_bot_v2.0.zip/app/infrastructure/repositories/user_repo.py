from typing import List, Optional

from sqlalchemy import select, and_, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.user import User, UserRole
from app.domain.dto.user import UserCreate, UserUpdate


class UserRepository:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, user_data: UserCreate) -> User:
        """Create a new user."""
        user = User(**user_data.dict())
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def get_by_id(self, user_id: int) -> Optional[User]:
        """Get user by ID."""
        result = await self.db.execute(
            select(User).where(User.id == user_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_telegram_id(self, telegram_id: str) -> Optional[User]:
        """Get user by Telegram ID."""
        result = await self.db.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()
    
    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User]:
        """Get all users."""
        result = await self.db.execute(
            select(User).offset(skip).limit(limit)
        )
        return result.scalars().all()
    
    async def update(self, user_id: int, update_data: UserUpdate) -> Optional[User]:
        """Update user."""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        for field, value in update_data.dict(exclude_unset=True).items():
            setattr(user, field, value)
        
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def update_role(self, user_id: int, role: UserRole) -> Optional[User]:
        """Update user role."""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        user.role = role
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def update_status(self, user_id: int, is_active: bool) -> Optional[User]:
        """Update user status."""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        user.is_active = is_active
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def ban_user(self, user_id: int) -> Optional[User]:
        """Ban user."""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        user.is_banned = True
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def unban_user(self, user_id: int) -> Optional[User]:
        """Unban user."""
        user = await self.get_by_id(user_id)
        if not user:
            return None
        
        user.is_banned = False
        await self.db.commit()
        await self.db.refresh(user)
        return user
    
    async def get_active_users(self) -> List[User]:
        """Get all active users."""
        result = await self.db.execute(
            select(User).where(User.is_active == True)
        )
        return result.scalars().all()
    
    async def get_filtered(
        self,
        skip: int = 0,
        limit: int = 100,
        is_active: Optional[bool] = None,
        is_admin: Optional[bool] = None
    ) -> List[User]:
        """Get users with filters."""
        query = select(User)
        
        filters = []
        if is_active is not None:
            filters.append(User.is_active == is_active)
        if is_admin is not None:
            filters.append(User.role == UserRole.ADMIN if is_admin else User.role == UserRole.USER)
        
        if filters:
            query = query.where(and_(*filters))
        
        query = query.offset(skip).limit(limit)
        
        result = await self.db.execute(query)
        return result.scalars().all()
    
    async def count(self) -> int:
        """Count all users."""
        result = await self.db.execute(
            select(func.count(User.id))
        )
        return result.scalar()