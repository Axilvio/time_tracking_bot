from datetime import datetime
from typing import List, Optional

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.reminder import Reminder


class ReminderRepository:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, reminder_data: dict) -> Reminder:
        """Create a new reminder."""
        reminder = Reminder(**reminder_data)
        self.db.add(reminder)
        await self.db.commit()
        await self.db.refresh(reminder)
        return reminder
    
    async def get_by_id(self, reminder_id: int) -> Optional[Reminder]:
        """Get reminder by ID."""
        result = await self.db.execute(
            select(Reminder).where(Reminder.id == reminder_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_user_id(self, user_id: int, skip: int = 0, limit: int = 100) -> List[Reminder]:
        """Get reminders by user ID."""
        result = await self.db.execute(
            select(Reminder)
            .where(Reminder.user_id == user_id)
            .order_by(Reminder.time)
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_unsent(self) -> List[Reminder]:
        """Get all unsent reminders."""
        now = datetime.utcnow()
        
        result = await self.db.execute(
            select(Reminder)
            .where(and_(
                Reminder.is_sent == False,
                Reminder.time <= now
            ))
        )
        return result.scalars().all()
    
    async def update(self, reminder_id: int, update_data: dict) -> Optional[Reminder]:
        """Update reminder."""
        reminder = await self.get_by_id(reminder_id)
        if not reminder:
            return None
        
        for field, value in update_data.items():
            setattr(reminder, field, value)
        
        await self.db.commit()
        await self.db.refresh(reminder)
        return reminder
    
    async def delete(self, reminder_id: int) -> bool:
        """Delete reminder."""
        reminder = await self.get_by_id(reminder_id)
        if not reminder:
            return False
        
        await self.db.delete(reminder)
        await self.db.commit()
        return True