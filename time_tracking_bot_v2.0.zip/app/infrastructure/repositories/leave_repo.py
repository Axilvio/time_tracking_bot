from datetime import date
from typing import List, Optional

from sqlalchemy import select, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.leave_period import LeavePeriod, LeaveType


class LeaveRepository:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, leave_data: dict) -> LeavePeriod:
        """Create a new leave period."""
        leave_period = LeavePeriod(**leave_data)
        self.db.add(leave_period)
        await self.db.commit()
        await self.db.refresh(leave_period)
        return leave_period
    
    async def get_by_id(self, period_id: int) -> Optional[LeavePeriod]:
        """Get leave period by ID."""
        result = await self.db.execute(
            select(LeavePeriod).where(LeavePeriod.id == period_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_user_id(self, user_id: int, skip: int = 0, limit: int = 100) -> List[LeavePeriod]:
        """Get leave periods by user ID."""
        result = await self.db.execute(
            select(LeavePeriod)
            .where(LeavePeriod.user_id == user_id)
            .order_by(LeavePeriod.start.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_active_by_user_id(self, user_id: int) -> List[LeavePeriod]:
        """Get active leave periods by user ID."""
        today = date.today()
        
        result = await self.db.execute(
            select(LeavePeriod)
            .where(and_(
                LeavePeriod.user_id == user_id,
                LeavePeriod.start <= today,
                or_(LeavePeriod.end >= today, LeavePeriod.end.is_(None))
            ))
        )
        return result.scalars().all()
    
    async def get_active_by_user_id_and_type(
        self,
        user_id: int,
        leave_type: str
    ) -> Optional[LeavePeriod]:
        """Get active leave period by user ID and type."""
        today = date.today()
        
        result = await self.db.execute(
            select(LeavePeriod)
            .where(and_(
                LeavePeriod.user_id == user_id,
                LeavePeriod.type == leave_type,
                LeavePeriod.start <= today,
                or_(LeavePeriod.end >= today, LeavePeriod.end.is_(None))
            ))
        )
        return result.scalar_one_or_none()
    
    async def get_overlapping_periods(
        self,
        user_id: int,
        start_date: date,
        end_date: Optional[date] = None
    ) -> List[LeavePeriod]:
        """Get overlapping leave periods."""
        if end_date is None:
            # Check for any overlap with the start date
            result = await self.db.execute(
                select(LeavePeriod)
                .where(and_(
                    LeavePeriod.user_id == user_id,
                    or_(
                        and_(LeavePeriod.start <= start_date, or_(LeavePeriod.end >= start_date, LeavePeriod.end.is_(None))),
                        and_(LeavePeriod.start >= start_date, LeavePeriod.end.is_(None))
                    )
                ))
            )
        else:
            # Check for any overlap with the date range
            result = await self.db.execute(
                select(LeavePeriod)
                .where(and_(
                    LeavePeriod.user_id == user_id,
                    or_(
                        and_(LeavePeriod.start <= end_date, or_(LeavePeriod.end >= start_date, LeavePeriod.end.is_(None))),
                        and_(LeavePeriod.start >= start_date, LeavePeriod.start <= end_date, LeavePeriod.end.is_(None))
                    )
                ))
            )
        
        return result.scalars().all()
    
    async def update(self, period_id: int, update_data: dict) -> Optional[LeavePeriod]:
        """Update leave period."""
        leave_period = await self.get_by_id(period_id)
        if not leave_period:
            return None
        
        for field, value in update_data.items():
            setattr(leave_period, field, value)
        
        await self.db.commit()
        await self.db.refresh(leave_period)
        return leave_period
    
    async def delete(self, period_id: int) -> bool:
        """Delete leave period."""
        leave_period = await self.get_by_id(period_id)
        if not leave_period:
            return False
        
        await self.db.delete(leave_period)
        await self.db.commit()
        return True