from datetime import date
from typing import List, Dict

from sqlalchemy import select, and_, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.work_session import WorkSession
from app.domain.models.break_session import BreakSession


class StatsRepository:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def get_work_time_by_user_and_date_range(
        self,
        user_id: int,
        start_date: date,
        end_date: date
    ) -> Dict:
        """Get work time statistics for a user in a date range."""
        # This is a simplified implementation - in a real scenario, you might want to
        # use more complex queries to calculate effective work time
        
        # Get work sessions
        result = await self.db.execute(
            select(
                func.sum(func.extract('epoch', WorkSession.end - WorkSession.start)).label('total_work_seconds'),
                func.count(WorkSession.id).label('session_count')
            )
            .where(and_(
                WorkSession.user_id == user_id,
                WorkSession.start >= start_date,
                WorkSession.start <= end_date,
                WorkSession.end.isnot(None)
            ))
        )
        
        work_data = result.first()
        total_work_seconds = work_data.total_work_seconds or 0
        session_count = work_data.session_count or 0
        
        # Get break time
        result = await self.db.execute(
            select(
                func.sum(func.extract('epoch', BreakSession.end - BreakSession.start)).label('total_break_seconds')
            )
            .where(and_(
                BreakSession.user_id == user_id,
                BreakSession.start >= start_date,
                BreakSession.start <= end_date,
                BreakSession.end.isnot(None)
            ))
        )
        
        break_data = result.first()
        total_break_seconds = break_data.total_break_seconds or 0
        
        # Calculate effective work time
        effective_work_seconds = total_work_seconds - total_break_seconds
        
        return {
            "total_work_seconds": total_work_seconds,
            "total_break_seconds": total_break_seconds,
            "effective_work_seconds": effective_work_seconds,
            "session_count": session_count
        }