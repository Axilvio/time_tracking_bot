from typing import List, Optional

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.domain.models.break_session import BreakSession


class BreakRepository:
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create(self, break_data: dict) -> BreakSession:
        """Create a new break session."""
        break_session = BreakSession(**break_data)
        self.db.add(break_session)
        await self.db.commit()
        await self.db.refresh(break_session)
        return break_session
    
    async def get_by_id(self, session_id: int) -> Optional[BreakSession]:
        """Get break session by ID."""
        result = await self.db.execute(
            select(BreakSession).where(BreakSession.id == session_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_user_id(self, user_id: int, skip: int = 0, limit: int = 100) -> List[BreakSession]:
        """Get break sessions by user ID."""
        result = await self.db.execute(
            select(BreakSession)
            .where(BreakSession.user_id == user_id)
            .order_by(BreakSession.start.desc())
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_active_by_user_id(self, user_id: int) -> Optional[BreakSession]:
        """Get active break session by user ID."""
        result = await self.db.execute(
            select(BreakSession)
            .where(and_(
                BreakSession.user_id == user_id,
                BreakSession.end.is_(None)
            ))
        )
        return result.scalar_one_or_none()
    
    async def get_by_work_session_id(self, work_session_id: int) -> List[BreakSession]:
        """Get break sessions by work session ID."""
        result = await self.db.execute(
            select(BreakSession)
            .where(BreakSession.work_session_id == work_session_id)
            .order_by(BreakSession.start)
        )
        return result.scalars().all()
    
    async def update(self, session_id: int, update_data: dict) -> Optional[BreakSession]:
        """Update break session."""
        break_session = await self.get_by_id(session_id)
        if not break_session:
            return None
        
        for field, value in update_data.items():
            setattr(break_session, field, value)
        
        await self.db.commit()
        await self.db.refresh(break_session)
        return break_session
    
    async def delete(self, session_id: int) -> bool:
        """Delete break session."""
        break_session = await self.get_by_id(session_id)
        if not break_session:
            return False
        
        await self.db.delete(break_session)
        await self.db.commit()
        return True