from telegram import Bot
from telegram.error import TelegramError

from app.infrastructure.notifications.base import NotificationChannel
from app.settings import settings


class TelegramChannel(NotificationChannel):
    """Telegram notification channel."""
    
    def __init__(self):
        self.bot = Bot(token=settings.bot_token)
    
    async def send_notification(self, user_id: str, message: str):
        """Send a notification via Telegram."""
        try:
            await self.bot.send_message(
                chat_id=user_id,
                text=message
            )
        except TelegramError as e:
            print(f"Failed to send Telegram notification: {e}")