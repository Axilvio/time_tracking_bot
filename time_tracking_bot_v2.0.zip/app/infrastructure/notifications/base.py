from abc import ABC, abstractmethod


class NotificationChannel(ABC):
    """Abstract base class for notification channels."""
    
    @abstractmethod
    async def send_notification(self, user_id: str, message: str):
        """Send a notification to a user."""
        pass