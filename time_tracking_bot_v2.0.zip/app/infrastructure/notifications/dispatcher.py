from typing import List

from app.infrastructure.notifications.base import NotificationChannel
from app.infrastructure.notifications.telegram import TelegramChannel


class NotificationDispatcher:
    """Dispatcher for sending notifications through different channels."""
    
    def __init__(self):
        self.channels: List[NotificationChannel] = [
            TelegramChannel()
        ]
    
    async def send_notification(self, user_id: str, message: str):
        """Send a notification through all available channels."""
        for channel in self.channels:
            await channel.send_notification(user_id, message)