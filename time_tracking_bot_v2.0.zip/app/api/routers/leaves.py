from datetime import date, datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_active_user, get_db
from app.domain.dto.leave import LeaveStartRequest, LeavePeriodResponse, LeaveEditRequest
from app.domain.models.user import User
from app.domain.services.leave_service import LeaveService
from app.infrastructure.repositories.leave_repo import LeaveRepository

router = APIRouter()


@router.post("/start", response_model=LeavePeriodResponse)
async def start_leave(
    request: LeaveStartRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Start a leave period."""
    leave_service = LeaveService(db)
    try:
        leave_period = await leave_service.start_leave(
            user_id=current_user.id,
            leave_type=request.leave_type,
            start_date=request.start_date,
            end_date=request.end_date
        )
        return LeavePeriodResponse.from_orm(leave_period)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/end", response_model=LeavePeriodResponse)
async def end_leave(
    leave_type: str,
    end_date: date,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """End the current leave period."""
    leave_service = LeaveService(db)
    try:
        leave_period = await leave_service.end_leave(
            user_id=current_user.id,
            leave_type=leave_type,
            end_date=end_date
        )
        return LeavePeriodResponse.from_orm(leave_period)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/history", response_model=List[LeavePeriodResponse])
async def get_leave_history(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get leave period history."""
    leave_repo = LeaveRepository(db)
    leave_periods = await leave_repo.get_by_user_id(
        user_id=current_user.id,
        skip=skip,
        limit=limit
    )
    return [LeavePeriodResponse.from_orm(period) for period in leave_periods]


@router.get("/current", response_model=List[LeavePeriodResponse])
async def get_current_leave_periods(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get current leave periods."""
    leave_repo = LeaveRepository(db)
    leave_periods = await leave_repo.get_active_by_user_id(current_user.id)
    return [LeavePeriodResponse.from_orm(period) for period in leave_periods]


@router.patch("/{period_id}", response_model=LeavePeriodResponse)
async def edit_leave_period(
    period_id: int,
    request: LeaveEditRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Edit a leave period."""
    leave_service = LeaveService(db)
    try:
        # Check if user owns the period or is admin
        leave_repo = LeaveRepository(db)
        period = await leave_repo.get_by_id(period_id)
        if period is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Leave period not found"
            )
        
        if period.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )
        
        leave_period = await leave_service.edit_leave_period(
            period_id=period_id,
            start_date=request.start_date,
            end_date=request.end_date
        )
        return LeavePeriodResponse.from_orm(leave_period)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )