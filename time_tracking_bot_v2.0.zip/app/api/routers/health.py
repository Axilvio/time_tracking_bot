from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.api.deps import get_db
from app.infrastructure.redis.client import get_redis_client

router = APIRouter()


@router.get("/")
async def health_check(
    db: AsyncSession = Depends(get_db)
):
    """Health check endpoint."""
    # Check database connection
    try:
        await db.execute(text("SELECT 1"))
        db_status = "healthy"
    except Exception:
        db_status = "unhealthy"
    
    # Check Redis connection
    try:
        redis = await get_redis_client()
        await redis.ping()
        redis_status = "healthy"
    except Exception:
        redis_status = "unhealthy"
    
    overall_status = "healthy" if db_status == "healthy" and redis_status == "healthy" else "unhealthy"
    
    return {
        "status": overall_status,
        "database": db_status,
        "redis": redis_status
    }