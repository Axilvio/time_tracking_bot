from datetime import date, datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_active_user, get_db
from app.domain.dto.stats import (
    WeeklyStatsResponse, MonthlyStatsResponse, UserStatsResponse,
    AdminStatsResponse, WorkSessionStatsResponse
)
from app.domain.models.user import User
from app.domain.services.stats_service import StatsService

router = APIRouter()


@router.get("/weekly", response_model=WeeklyStatsResponse)
async def get_weekly_stats(
    week_start: Optional[date] = Query(None, description="Start of the week (Monday)"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get weekly work statistics."""
    if week_start is None:
        # Default to current week
        today = date.today()
        week_start = today - timedelta(days=today.weekday())
    
    stats_service = StatsService(db)
    stats = await stats_service.get_weekly_stats(
        user_id=current_user.id,
        week_start=week_start
    )
    return WeeklyStatsResponse.from_dict(stats)


@router.get("/monthly", response_model=MonthlyStatsResponse)
async def get_monthly_stats(
    year: Optional[int] = Query(None, description="Year"),
    month: Optional[int] = Query(None, description="Month (1-12)"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get monthly work statistics."""
    if year is None or month is None:
        # Default to current month
        today = date.today()
        year = today.year
        month = today.month
    
    stats_service = StatsService(db)
    stats = await stats_service.get_monthly_stats(
        user_id=current_user.id,
        year=year,
        month=month
    )
    return MonthlyStatsResponse.from_dict(stats)


@router.get("/user/{user_id}", response_model=UserStatsResponse)
async def get_user_stats(
    user_id: int,
    start_date: date,
    end_date: date,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get statistics for a specific user."""
    # Check if user is requesting their own stats or is admin
    if user_id != current_user.id and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    stats_service = StatsService(db)
    stats = await stats_service.get_user_stats(
        user_id=user_id,
        start_date=start_date,
        end_date=end_date
    )
    return UserStatsResponse.from_dict(stats)


@router.get("/admin/overview", response_model=AdminStatsResponse)
async def get_admin_stats(
    start_date: date,
    end_date: date,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get admin overview statistics."""
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    stats_service = StatsService(db)
    stats = await stats_service.get_admin_stats(
        start_date=start_date,
        end_date=end_date
    )
    return AdminStatsResponse.from_dict(stats)


@router.get("/work-sessions", response_model=List[WorkSessionStatsResponse])
async def get_work_session_stats(
    start_date: date,
    end_date: date,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get detailed work session statistics."""
    stats_service = StatsService(db)
    sessions = await stats_service.get_work_session_stats(
        user_id=current_user.id,
        start_date=start_date,
        end_date=end_date
    )
    return [WorkSessionStatsResponse.from_dict(session) for session in sessions]