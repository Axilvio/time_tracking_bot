from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_active_user, get_db
from app.domain.dto import BreakStartRequest, BreakSessionResponse, BreakEditRequest
from app.domain.models.user import User
from app.domain.services.break_service import BreakService
from app.infrastructure.repositories.break_repo import BreakRepository

router = APIRouter()


@router.post("/start", response_model=BreakSessionResponse)
async def start_break(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Start a break session."""
    break_service = BreakService(db)
    try:
        break_session = await break_service.start_break(current_user.id)
        return BreakSessionResponse.from_orm(break_session)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/end", response_model=BreakSessionResponse)
async def end_break(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """End the current break session."""
    break_service = BreakService(db)
    try:
        break_session = await break_service.end_break(current_user.id)
        return BreakSessionResponse.from_orm(break_session)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/history", response_model=List[BreakSessionResponse])
async def get_break_history(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get break session history."""
    break_repo = BreakRepository(db)
    break_sessions = await break_repo.get_by_user_id(
        user_id=current_user.id,
        skip=skip,
        limit=limit
    )
    return [BreakSessionResponse.from_orm(session) for session in break_sessions]


@router.get("/current", response_model=BreakSessionResponse)
async def get_current_break_session(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get the current break session."""
    break_repo = BreakRepository(db)
    break_session = await break_repo.get_active_by_user_id(current_user.id)
    if break_session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No active break session"
        )
    return BreakSessionResponse.from_orm(break_session)


@router.patch("/{session_id}", response_model=BreakSessionResponse)
async def edit_break_session(
    session_id: int,
    request: BreakEditRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Edit a break session."""
    break_service = BreakService(db)
    try:
        # Check if user owns the session or is admin
        break_repo = BreakRepository(db)
        session = await break_repo.get_by_id(session_id)
        if session is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Break session not found"
            )
        
        # Get work session to check ownership
        work_repo = WorkSessionRepository(db)
        work_session = await work_repo.get_by_id(session.work_session_id)
        if work_session.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )
        
        break_session = await break_service.edit_break_session(
            session_id=session_id,
            start_time=request.start_time,
            end_time=request.end_time
        )
        return BreakSessionResponse.from_orm(break_session)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )