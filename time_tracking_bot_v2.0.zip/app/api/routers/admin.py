from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_admin_user, get_db
from app.domain.dto.admin import (
    AuditLogResponse, UserManagementResponse, NotificationRequest
)
from app.domain.models.user import User
from app.domain.services.audit_service import AuditService
from app.domain.services.user_service import UserService
from app.domain.services.notification_service import NotificationService
from app.infrastructure.repositories.audit_repo import AuditRepository
from app.infrastructure.repositories.user_repo import UserRepository

router = APIRouter()


@router.get("/audit-logs", response_model=List[AuditLogResponse])
async def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    user_id: int = None,
    action: str = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Get audit logs."""
    audit_repo = AuditRepository(db)
    logs = await audit_repo.get_filtered(
        skip=skip,
        limit=limit,
        user_id=user_id,
        action=action
    )
    return [AuditLogResponse.from_orm(log) for log in logs]


@router.get("/users", response_model=List[UserManagementResponse])
async def get_users_for_management(
    skip: int = 0,
    limit: int = 100,
    is_active: bool = None,
    is_admin: bool = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Get users for management."""
    user_repo = UserRepository(db)
    users = await user_repo.get_filtered(
        skip=skip,
        limit=limit,
        is_active=is_active,
        is_admin=is_admin
    )
    return [UserManagementResponse.from_orm(user) for user in users]


@router.post("/notify")
async def send_notification(
    request: NotificationRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Send notification to users."""
    notification_service = NotificationService(db)
    await notification_service.send_notification_to_users(
        message=request.message,
        user_ids=request.user_ids
    )
    return {"message": "Notification sent successfully"}


@router.post("/migrate-v1")
async def migrate_from_v1(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Migrate data from v1 database."""
    from scripts.migrate_v1_to_v2 import migrate_data
    
    try:
        result = await migrate_data(db)
        return {"message": f"Migration completed successfully. {result}"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Migration failed: {str(e)}"
        )