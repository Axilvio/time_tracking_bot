from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_active_user, get_db
from app.domain.dto.reminder import ReminderCreateRequest, ReminderResponse
from app.domain.models.user import User
from app.domain.services.reminder_service import ReminderService
from app.infrastructure.repositories.reminder_repo import ReminderRepository

router = APIRouter()


@router.post("/", response_model=ReminderResponse)
async def create_reminder(
    request: ReminderCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a reminder."""
    reminder_service = ReminderService(db)
    try:
        reminder = await reminder_service.create_reminder(
            user_id=current_user.id,
            time=request.time,
            message=request.message
        )
        return ReminderResponse.from_orm(reminder)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/", response_model=List[ReminderResponse])
async def get_reminders(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get reminders."""
    reminder_repo = ReminderRepository(db)
    reminders = await reminder_repo.get_by_user_id(
        user_id=current_user.id,
        skip=skip,
        limit=limit
    )
    return [ReminderResponse.from_orm(reminder) for reminder in reminders]


@router.get("/{reminder_id}", response_model=ReminderResponse)
async def get_reminder(
    reminder_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get reminder by ID."""
    reminder_repo = ReminderRepository(db)
    reminder = await reminder_repo.get_by_id(reminder_id)
    if reminder is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reminder not found"
        )
    
    if reminder.user_id != current_user.id and not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    return ReminderResponse.from_orm(reminder)


@router.delete("/{reminder_id}")
async def delete_reminder(
    reminder_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete a reminder."""
    reminder_service = ReminderService(db)
    try:
        # Check if user owns the reminder or is admin
        reminder_repo = ReminderRepository(db)
        reminder = await reminder_repo.get_by_id(reminder_id)
        if reminder is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Reminder not found"
            )
        
        if reminder.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )
        
        await reminder_service.delete_reminder(reminder_id)
        return {"message": "Reminder deleted successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )