from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_current_active_user, get_db
from app.domain.dto.work import WorkStartRequest, WorkSessionResponse, WorkEditRequest
from app.domain.models.user import User
from app.domain.services.work_service import WorkSessionService
from app.infrastructure.repositories.work_repo import WorkSessionRepository

router = APIRouter()


@router.post("/start", response_model=WorkSessionResponse)
async def start_work(
    request: WorkStartRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Start a work session."""
    work_service = WorkSessionService(db)
    try:
        work_session = await work_service.start_work(
            user_id=current_user.id,
            location=request.location,
            start_time=request.start_time
        )
        return WorkSessionResponse.from_orm(work_session)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.post("/end", response_model=WorkSessionResponse)
async def end_work(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """End the current work session."""
    work_service = WorkSessionService(db)
    try:
        work_session = await work_service.end_work(current_user.id)
        return WorkSessionResponse.from_orm(work_session)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get("/history", response_model=List[WorkSessionResponse])
async def get_work_history(
    skip: int = 0,
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get work session history."""
    work_repo = WorkSessionRepository(db)
    work_sessions = await work_repo.get_by_user_id(
        user_id=current_user.id,
        skip=skip,
        limit=limit
    )
    return [WorkSessionResponse.from_orm(session) for session in work_sessions]


@router.get("/current", response_model=WorkSessionResponse)
async def get_current_work_session(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get the current work session."""
    work_repo = WorkSessionRepository(db)
    work_session = await work_repo.get_active_by_user_id(current_user.id)
    if work_session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No active work session"
        )
    return WorkSessionResponse.from_orm(work_session)


@router.patch("/{session_id}", response_model=WorkSessionResponse)
async def edit_work_session(
    session_id: int,
    request: WorkEditRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Edit a work session."""
    work_service = WorkSessionService(db)
    try:
        # Check if user owns the session or is admin
        work_repo = WorkSessionRepository(db)
        session = await work_repo.get_by_id(session_id)
        if session is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Work session not found"
            )
        
        if session.user_id != current_user.id and not current_user.is_admin:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )
        
        work_session = await work_service.edit_work_session(
            session_id=session_id,
            start_time=request.start_time,
            end_time=request.end_time
        )
        return WorkSessionResponse.from_orm(work_session)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )