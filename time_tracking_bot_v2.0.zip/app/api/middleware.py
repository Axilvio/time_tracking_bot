import hmac
import hashlib
import json
import logging
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, urlparse
from fastapi import FastAPI, HTTPException, Request, Response, status
from fastapi.middleware.base import BaseHTTPMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from starlette.middleware.base import RequestResponseEndpoint
from starlette.requests import Request
from jose import jwt, JWTError

from app.settings import settings

logger = logging.getLogger(__name__)

# Rate limiter
limiter = Limiter(key_func=get_remote_address)


class AuthMiddleware(BaseHTTPMiddleware):
    """Middleware for authentication with Telegram WebApp data and JWT."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        """Process request and handle authentication."""
        # Skip auth for health endpoint
        if request.url.path.startswith("/api/health"):
            return await call_next(request)
        
        # Skip auth for auth endpoints
        if request.url.path.startswith("/api/auth"):
            return await call_next(request)
        
        # For WebSocket connections, we'll handle auth in the endpoint
        if request.url.path.startswith("/ws"):
            return await call_next(request)
        
        # Check for Authorization header (JWT)
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            try:
                # Validate JWT token
                payload = jwt.decode(
                    auth_header.split(" ")[1],
                    settings.jwt_secret,
                    algorithms=[settings.jwt_algorithm]
                )
                # Store user_id in request state
                request.state.user_id = int(payload.get("sub"))
                return await call_next(request)
            except JWTError as e:
                logger.warning(f"JWT validation failed: {e}")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid token"
                )
        
        # Check for Telegram WebApp init data
        auth_data = request.headers.get("X-Telegram-Auth")
        if auth_data:
            try:
                # Validate Telegram WebApp init data
                if self.validate_telegram_data(auth_data):
                    # Extract user_id from init data
                    parsed_data = parse_qs(auth_data)
                    user_data = json.loads(parsed_data.get("user", ["{}"])[0])
                    if user_data:
                        request.state.user_id = user_data.get("id")
                    return await call_next(request)
            except Exception as e:
                logger.warning(f"Telegram auth validation failed: {e}")
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Invalid Telegram auth data: {str(e)}"
                )
        
        # For Mini App requests, check for Telegram init data in query params
        if request.url.path.startswith("/mini-app"):
            query_string = str(request.query_params)
            if query_string:
                try:
                    if self.validate_telegram_data(query_string):
                        # Extract user_id from init data
                        parsed_data = parse_qs(query_string)
                        user_data = json.loads(parsed_data.get("user", ["{}"])[0])
                        if user_data:
                            request.state.user_id = user_data.get("id")
                        return await call_next(request)
                except Exception as e:
                    logger.warning(f"Mini App auth validation failed: {e}")
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=f"Invalid Telegram auth data: {str(e)}"
                    )
        
        logger.warning(f"Unauthenticated request to {request.url.path}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated"
        )
    
    def validate_telegram_data(self, auth_data: str) -> bool:
        """Validate Telegram WebApp init data."""
        try:
            # Parse auth data
            parsed_data = parse_qs(auth_data)
            hash_value = parsed_data.get("hash", [None])[0]
            
            if not hash_value:
                return False
            
            # Create data check string
            data_check_arr = []
            for key in sorted(parsed_data.keys()):
                if key != "hash":
                    data_check_arr.append(f"{key}={parsed_data[key][0]}")
            data_check_string = "\n".join(data_check_arr)
            
            # Create secret key
            secret_key = hmac.new(
                key=b"WebAppData",
                msg=settings.bot_token.encode(),
                digestmod=hashlib.sha256
            ).digest()
            
            # Calculate hash
            calculated_hash = hmac.new(
                key=secret_key,
                msg=data_check_string.encode(),
                digestmod=hashlib.sha256
            ).hexdigest()
            
            # Compare hashes using secure comparison
            return hmac.compare_digest(calculated_hash, hash_value)
        except Exception as e:
            logger.error(f"Error validating Telegram data: {e}", exc_info=True)
            return False


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware for rate limiting."""

    def __init__(self, app: FastAPI):
        super().__init__(app)
        self.state = {"limiter": limiter}

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        """Process request with rate limiting."""
        try:
            return await call_next(request)
        except RateLimitExceeded as e:
            logger.warning(f"Rate limit exceeded for {get_remote_address(request)}: {e}")
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=str(e)
            )


# Store current user ID in request state
async def get_current_user_id(request: Request) -> Optional[int]:
    """Get current user ID from request state."""
    return getattr(request.state, "user_id", None)


# Get user ID from JWT token
async def get_user_id_from_token(
    credentials: str = None
) -> Optional[int]:
    """Get user ID from JWT token."""
    if not credentials:
        return None
    
    try:
        payload = jwt.decode(
            credentials,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm]
        )
        user_id: int = payload.get("sub")
        return user_id
    except JWTError:
        return None