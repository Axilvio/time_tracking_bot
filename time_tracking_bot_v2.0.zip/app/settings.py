from typing import List, Optional
from pydantic import BaseSettings, validator


class Settings(BaseSettings):
    # App Configuration
    app_name: str = "Arkady v2"
    app_version: str = "0.1.0"
    debug: bool = False
    log_level: str = "INFO"
    
    # Bot Configuration
    bot_token: str
    webhook_url: Optional[str] = None
    notification_chat_id: Optional[str] = None
    
    # Database Configuration
    db_url: str
    
    # Redis Configuration
    redis_url: str
    
    # JWT Configuration
    jwt_secret: str
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 15
    jwt_refresh_token_expire_days: int = 7
    
    # CORS Configuration
    allowed_origins: List[str] = []
    
    # Mini App Configuration
    mini_app_url: Optional[str] = None
    
    # Timezone Configuration
    default_timezone: str = "UTC"
    
    @validator("allowed_origins", pre=True)
    def parse_allowed_origins(cls, v):
        if isinstance(v, str):
            return [i.strip() for i in v.split(",")]
        return v
    
    class Config:
        env_file = ".env"


settings = Settings()