import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { workApi } from '../api/work'
import { breaksApi } from '../api/breaks'
import { useTelegram } from '../hooks/useTelegram'

interface ButtonsProps {
  isWorking: boolean
  isOnBreak: boolean
  isOnLeave: boolean
}

const Buttons: React.FC<ButtonsProps> = ({
  isWorking,
  isOnBreak,
  isOnLeave,
}) => {
  const navigate = useNavigate()
  const { tg } = useTelegram()
  const queryClient = useQueryClient()

  // Start work mutation
  const startWorkMutation = useMutation({
    mutationFn: workApi.startWork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentWorkSession'] })
      queryClient.invalidateQueries({ queryKey: ['workHistory'] })
    },
  })

  // End work mutation
  const endWorkMutation = useMutation({
    mutationFn: workApi.endWork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentWorkSession'] })
      queryClient.invalidateQueries({ queryKey: ['workHistory'] })
    },
  })

  // Start break mutation
  const startBreakMutation = useMutation({
    mutationFn: breaksApi.startBreak,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentBreakSession'] })
      queryClient.invalidateQueries({ queryKey: ['breakHistory'] })
    },
  })

  // End break mutation
  const endBreakMutation = useMutation({
    mutationFn: breaksApi.endBreak,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentBreakSession'] })
      queryClient.invalidateQueries({ queryKey: ['breakHistory'] })
    },
  })

  // Set up Telegram main button based on current state
  React.useEffect(() => {
    if (tg) {
      if (!isWorking && !isOnLeave) {
        tg.MainButton.text = 'Начать работу'
        tg.MainButton.color = '#2481cc'
        tg.MainButton.onClick(() => navigate('/work'))
        tg.MainButton.show()
      } else if (isWorking && !isOnBreak) {
        tg.MainButton.text = 'Начать перерыв'
        tg.MainButton.color = '#f5a623'
        tg.MainButton.onClick(() => startBreakMutation.mutate())
        tg.MainButton.show()
      } else if (isOnBreak) {
        tg.MainButton.text = 'Завершить перерыв'
        tg.MainButton.color = '#2481cc'
        tg.MainButton.onClick(() => endBreakMutation.mutate())
        tg.MainButton.show()
      } else {
        tg.MainButton.hide()
      }

      return () => {
        tg.MainButton.offClick(() => {})
      }
    }
  }, [tg, isWorking, isOnBreak, isOnLeave, navigate, startBreakMutation, endBreakMutation])

  return (
    <div className="card">
      <h3>Действия</h3>

      {!isWorking && !isOnLeave && (
        <button
          className="button"
          onClick={() => navigate('/work')}
          disabled={startWorkMutation.isLoading}
        >
          Начать работу
        </button>
      )}

      {isWorking && !isOnBreak && (
        <button
          className="button"
          onClick={() => startBreakMutation.mutate()}
          disabled={startBreakMutation.isLoading}
        >
          Начать перерыв
        </button>
      )}

      {isOnBreak && (
        <button
          className="button"
          onClick={() => endBreakMutation.mutate()}
          disabled={endBreakMutation.isLoading}
        >
          Завершить перерыв
        </button>
      )}

      {isWorking && (
        <button
          className="button"
          onClick={() => endWorkMutation.mutate()}
          disabled={endWorkMutation.isLoading}
        >
          Завершить работу
        </button>
      )}

      <button className="button secondary" onClick={() => navigate('/history')}>
        История
      </button>

      <button className="button secondary" onClick={() => navigate('/stats')}>
        Статистика
      </button>
    </div>
  )
}

export default Buttons