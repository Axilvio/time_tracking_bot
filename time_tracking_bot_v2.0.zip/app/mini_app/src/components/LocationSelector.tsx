import React, { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { workApi } from '../api/work'

interface LocationSelectorProps {
  value: string
  onChange: (value: string) => void
  onLocationSelected?: (location: string) => void
  disabled?: boolean
}

const LocationSelector: React.FC<LocationSelectorProps> = ({ 
  value, 
  onChange, 
  onLocationSelected,
  disabled = false
}) => {
  const [isLoading, setIsLoading] = useState(false)
  const queryClient = useQueryClient()
  
  // Start work mutation
  const startWorkMutation = useMutation({
    mutationFn: workApi.startWork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentWorkSession'] })
      queryClient.invalidateQueries({ queryKey: ['workHistory'] })
      if (onLocationSelected) {
        onLocationSelected(value)
      }
    },
    onError: (error) => {
      console.error('Error starting work:', error)
      setIsLoading(false)
    },
  })

  const locations = [
    { value: 'office', label: 'В офисе' },
    { value: 'remote', label: 'Удалённо' },
    { value: 'site', label: 'На площадке' },
  ]

  const handleLocationSelect = async (locationValue: string) => {
    if (disabled || isLoading) return
    
    setIsLoading(true)
    onChange(locationValue)
    
    // Auto-start work if onLocationSelected is provided
    if (onLocationSelected) {
      try {
        await startWorkMutation.mutateAsync({ location: locationValue })
      } finally {
        setIsLoading(false)
      }
    } else {
      setIsLoading(false)
    }
  }

  return (
    <div className="form-group">
      <label>Местоположение:</label>
      <div className="location-options">
        {locations.map((location) => (
          <button
            key={location.value}
            className={`button ${value === location.value ? '' : 'secondary'}`}
            onClick={() => handleLocationSelect(location.value)}
            disabled={disabled || isLoading}
          >
            {location.label}
          </button>
        ))}
      </div>
      
      {isLoading && (
        <div className="loading">Начинаем работу...</div>
      )}
      
      {startWorkMutation.isError && (
        <div className="error">
          Ошибка при начале работы: {startWorkMutation.error.message}
        </div>
      )}
    </div>
  )
}

export default LocationSelector