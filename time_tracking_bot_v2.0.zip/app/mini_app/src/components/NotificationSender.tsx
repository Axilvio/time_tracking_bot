import React, { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { authApi } from '../api/auth'

const NotificationSender: React.FC = () => {
  const [message, setMessage] = useState('')
  const queryClient = useQueryClient()

  // Send notification mutation
  const sendNotificationMutation = useMutation({
    mutationFn: (data: { message: string; user_ids?: number[] }) =>
      authApi.sendNotificationToUsers(data),
    onSuccess: () => {
      setMessage('')
      alert('Уведомление отправлено!')
    },
  })

  const handleSendNotification = () => {
    if (!message.trim()) {
      alert('Пожалуйста, введите сообщение')
      return
    }

    sendNotificationMutation.mutate({ message })
  }

  return (
    <div className="card">
      <h3>Отправка уведомлений</h3>

      <div className="form-group">
        <label>Сообщение:</label>
        <textarea
          className="input"
          rows={4}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Введите сообщение для отправки пользователям"
        />
      </div>

      <button
        className="button"
        onClick={handleSendNotification}
        disabled={sendNotificationMutation.isLoading}
      >
        Отправить всем
      </button>

      {sendNotificationMutation.isLoading && (
        <p>Отправка уведомления...</p>
      )}

      {sendNotificationMutation.isError && (
        <div className="error">
          Ошибка при отправке уведомления: {sendNotificationMutation.error.message}
        </div>
      )}
    </div>
  )
}

export default NotificationSender