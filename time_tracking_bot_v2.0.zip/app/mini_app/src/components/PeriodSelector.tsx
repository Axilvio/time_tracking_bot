import React from 'react'

interface PeriodSelectorProps {
  period: {
    type: string
    startDate: string
    endDate: string
  }
  onChange: (period: any) => void
}

const PeriodSelector: React.FC<PeriodSelectorProps> = ({ period, onChange }) => {
  const handleTypeChange = (type: string) => {
    onChange({ ...period, type })
  }

  const handleStartDateChange = (startDate: string) => {
    onChange({ ...period, startDate })
  }

  const handleEndDateChange = (endDate: string) => {
    onChange({ ...period, endDate })
  }

  const setWeekPeriod = () => {
    const today = new Date()
    const startOfWeek = new Date(today)
    startOfWeek.setDate(today.getDate() - today.getDay())
    
    onChange({
      type: 'week',
      startDate: startOfWeek.toISOString().split('T')[0],
      endDate: today.toISOString().split('T')[0],
    })
  }

  const setMonthPeriod = () => {
    const today = new Date()
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1)
    
    onChange({
      type: 'month',
      startDate: startOfMonth.toISOString().split('T')[0],
      endDate: today.toISOString().split('T')[0],
    })
  }

  return (
    <div className="period-selector">
      <div className="form-group">
        <label>Период:</label>
        <div className="period-options">
          <button
            className={`button ${period.type === 'week' ? '' : 'secondary'}`}
            onClick={setWeekPeriod}
          >
            Неделя
          </button>
          <button
            className={`button ${period.type === 'month' ? '' : 'secondary'}`}
            onClick={setMonthPeriod}
          >
            Месяц
          </button>
          <button
            className={`button ${period.type === 'custom' ? '' : 'secondary'}`}
            onClick={() => handleTypeChange('custom')}
          >
            Произвольный
          </button>
        </div>
      </div>

      {period.type === 'custom' && (
        <>
          <div className="form-group">
            <label>Начальная дата:</label>
            <input
              type="date"
              className="input"
              value={period.startDate}
              onChange={(e) => handleStartDateChange(e.target.value)}
            />
          </div>

          <div className="form-group">
            <label>Конечная дата:</label>
            <input
              type="date"
              className="input"
              value={period.endDate}
              onChange={(e) => handleEndDateChange(e.target.value)}
            />
          </div>
        </>
      )}
    </div>
  )
}

export default PeriodSelector