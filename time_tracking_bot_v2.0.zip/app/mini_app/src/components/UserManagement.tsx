import React, { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { authApi } from '../api/auth'

const UserManagement: React.FC = () => {
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const queryClient = useQueryClient()

  // Fetch users
  const { data: users } = useQuery({
    queryKey: ['users'],
    queryFn: authApi.getUsers,
  })

  // Update user role mutation
  const updateRoleMutation = useMutation({
    mutationFn: ({ userId, isAdmin }: { userId: number; isAdmin: boolean }) =>
      authApi.updateUserRole(userId, isAdmin),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] })
      setSelectedUser(null)
    },
  })

  // Update user status mutation
  const updateStatusMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: number; isActive: boolean }) =>
      authApi.updateUserStatus(userId, isActive),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] })
      setSelectedUser(null)
    },
  })

  const handleUserSelect = (user: any) => {
    setSelectedUser(user)
  }

  const handleRoleToggle = (isAdmin: boolean) => {
    if (!selectedUser) return

    updateRoleMutation.mutate({
      userId: selectedUser.id,
      isAdmin,
    })
  }

  const handleStatusToggle = (isActive: boolean) => {
    if (!selectedUser) return

    updateStatusMutation.mutate({
      userId: selectedUser.id,
      isActive,
    })
  }

  return (
    <div className="card">
      <h3>Управление пользователями</h3>

      {users?.data?.length ? (
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Имя</th>
              <th>Username</th>
              <th>Роль</th>
              <th>Статус</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {users.data.map((user: any) => (
              <tr
                key={user.id}
                className={selectedUser?.id === user.id ? 'selected' : ''}
                onClick={() => handleUserSelect(user)}
              >
                <td>{user.id}</td>
                <td>
                  {user.first_name} {user.last_name || ''}
                </td>
                <td>@{user.username || 'N/A'}</td>
                <td>{user.is_admin ? 'Админ' : 'Пользователь'}</td>
                <td>{user.is_active ? 'Активен' : 'Неактивен'}</td>
                <td>
                  <button className="button secondary">Изменить</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Нет пользователей.</p>
      )}

      {selectedUser && (
        <div className="user-actions">
          <h4>Действия для пользователя {selectedUser.first_name}</h4>

          <div className="form-group">
            <label>Роль:</label>
            <div className="button-group">
              <button
                className={`button ${selectedUser.is_admin ? '' : 'secondary'}`}
                onClick={() => handleRoleToggle(true)}
                disabled={updateRoleMutation.isLoading}
              >
                Сделать админом
              </button>
              <button
                className={`button ${!selectedUser.is_admin ? '' : 'secondary'}`}
                onClick={() => handleRoleToggle(false)}
                disabled={updateRoleMutation.isLoading}
              >
                Сделать пользователем
              </button>
            </div>
          </div>

          <div className="form-group">
            <label>Статус:</label>
            <div className="button-group">
              <button
                className={`button ${selectedUser.is_active ? '' : 'secondary'}`}
                onClick={() => handleStatusToggle(true)}
                disabled={updateStatusMutation.isLoading}
              >
                Активировать
              </button>
              <button
                className={`button ${!selectedUser.is_active ? '' : 'secondary'}`}
                onClick={() => handleStatusToggle(false)}
                disabled={updateStatusMutation.isLoading}
              >
                Деактивировать
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default UserManagement