import React, { useState } from 'react'

interface TimeEditorProps {
  session: any
  onSave: (data: any) => void
  onCancel: () => void
}

const TimeEditor: React.FC<TimeEditorProps> = ({ session, onSave, onCancel }) => {
  const [startTime, setStartTime] = useState(
    session.start ? new Date(session.start).toISOString().slice(0, 16) : ''
  )
  const [endTime, setEndTime] = useState(
    session.end ? new Date(session.end).toISOString().slice(0, 16) : ''
  )

  const handleSave = () => {
    const data: any = {}

    if (startTime) {
      data.start_time = new Date(startTime).toISOString()
    }

    if (endTime) {
      data.end_time = new Date(endTime).toISOString()
    }

    onSave(data)
  }

  return (
    <div className="card">
      <h3>Редактирование сессии</h3>

      <div className="form-group">
        <label>Время начала:</label>
        <input
          type="datetime-local"
          className="input"
          value={startTime}
          onChange={(e) => setStartTime(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label>Время окончания:</label>
        <input
          type="datetime-local"
          className="input"
          value={endTime}
          onChange={(e) => setEndTime(e.target.value)}
        />
      </div>

      <div className="button-group">
        <button className="button" onClick={handleSave}>
          Сохранить
        </button>
        <button className="button secondary" onClick={onCancel}>
          Отмена
        </button>
      </div>
    </div>
  )
}

export default TimeEditor