import React from 'react'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { useTelegram } from '../hooks/useTelegram'

const Layout: React.FC = () => {
  const { user, logout } = useAuth()
  const { tg } = useTelegram()
  const location = useLocation()
  const navigate = useNavigate()

  const handleNavigation = (path: string) => {
    navigate(path)
  }

  const handleLogout = () => {
    logout()
  }

  // Set up Telegram main button
  React.useEffect(() => {
    if (tg) {
      tg.MainButton.text = 'Закрыть'
      tg.MainButton.color = '#ff3333'
      tg.MainButton.onClick(() => {
        tg.close()
      })
      tg.MainButton.show()
    }

    return () => {
      if (tg) {
        tg.MainButton.offClick(() => {
          tg.close()
        })
        tg.MainButton.hide()
      }
    }
  }, [tg])

  return (
    <div className="container">
      <div className="card">
        <h1>Arkady v2</h1>
        <p>Привет, {user?.first_name}!</p>
      </div>

      <div className="nav">
        <div
          className={`nav-item ${location.pathname === '/' ? 'active' : ''}`}
          onClick={() => handleNavigation('/')}
        >
          Главная
        </div>
        <div
          className={`nav-item ${location.pathname === '/work' ? 'active' : ''}`}
          onClick={() => handleNavigation('/work')}
        >
          Работа
        </div>
        <div
          className={`nav-item ${location.pathname === '/history' ? 'active' : ''}`}
          onClick={() => handleNavigation('/history')}
        >
          История
        </div>
        <div
          className={`nav-item ${location.pathname === '/stats' ? 'active' : ''}`}
          onClick={() => handleNavigation('/stats')}
        >
          Статистика
        </div>
        {user?.is_admin && (
          <div
            className={`nav-item ${location.pathname === '/admin' ? 'active' : ''}`}
            onClick={() => handleNavigation('/admin')}
          >
            Админ
          </div>
        )}
      </div>

      <Outlet />

      <div className="card">
        <button className="button secondary" onClick={handleLogout}>
          Выйти
        </button>
      </div>
    </div>
  )
}

export default Layout