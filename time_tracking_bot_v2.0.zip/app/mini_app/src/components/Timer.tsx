import React, { useEffect, useState, useCallback, useRef } from 'react'
import { useQuery } from '@tanstack/react-query'
import { workApi } from '../api/work'
import { breaksApi } from '../api/breaks'

interface TimerProps {
  userId?: number
  showControls?: boolean
  className?: string
}

const Timer: React.FC<TimerProps> = ({ 
  userId, 
  showControls = false, 
  className = ''
}) => {
  const [elapsedTime, setElapsedTime] = useState(0)
  const [isPaused, setIsPaused] = useState(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  // Fetch current work session
  const { data: workSession } = useQuery({
    queryKey: ['currentWorkSession'],
    queryFn: () => workApi.getCurrentWorkSession(),
    refetchInterval: 30000, // Refetch every 30 seconds
  })

  // Fetch current break session
  const { data: breakSession } = useQuery({
    queryKey: ['currentBreakSession'],
    queryFn: () => breaksApi.getCurrentBreakSession(),
    refetchInterval: 30000, // Refetch every 30 seconds
  })

  // Calculate elapsed time
  const calculateElapsedTime = useCallback(() => {
    if (!workSession?.data?.start) return 0

    const start = new Date(workSession.data.start).getTime()
    const now = Date.now()
    
    // If on break, calculate break time
    if (breakSession?.data?.start) {
      const breakStart = new Date(breakSession.data.start).getTime()
      return now - breakStart
    }
    
    // Otherwise calculate work time
    return now - start
  }, [workSession?.data?.start, breakSession?.data?.start])

  // Update timer
  useEffect(() => {
    if (isPaused) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
      return
    }

    intervalRef.current = setInterval(() => {
      setElapsedTime(calculateElapsedTime())
    }, 1000)

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
        intervalRef.current = null
      }
    }
  }, [calculateElapsedTime, isPaused])

  // Check if timer should be running
  useEffect(() => {
    const isRunning = !!(workSession?.data?.end)
    setIsPaused(!isRunning)
  }, [workSession?.data?.end])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [])

  const formatTime = (milliseconds: number) => {
    const totalSeconds = Math.floor(milliseconds / 1000)
    const hours = Math.floor(totalSeconds / 3600)
    const minutes = Math.floor((totalSeconds % 3600) / 60)
    const seconds = totalSeconds % 60

    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
  }

  const handleStartBreak = async () => {
    try {
      await breaksApi.startBreak()
    } catch (error) {
      console.error('Error starting break:', error)
    }
  }

  const handleEndBreak = async () => {
    try {
      await breaksApi.endBreak()
    } catch (error) {
      console.error('Error ending break:', error)
    }
  }

  const handleEndWork = async () => {
    try {
      await workApi.endWork()
    } catch (error) {
      console.error('Error ending work:', error)
    }
  }

  const getSessionType = () => {
    if (breakSession?.data) return 'break'
    if (workSession?.data) return 'work'
    return 'none'
  }

  const getSessionTitle = () => {
    switch (getSessionType()) {
      case 'break': return 'Перерыв'
      case 'work': return 'Работа'
      default: return 'Нет сессии'
    }
  }

  return (
    <div className={`card timer-card ${className}`}>
      <h3>{getSessionTitle()}</h3>
      
      <div className="timer">
        {formatTime(elapsedTime)}
      </div>
      
      {showControls && (
        <div className="timer-controls">
          {workSession?.data && !breakSession?.data && (
            <button className="button" onClick={handleStartBreak}>
              Начать перерыв
            </button>
          )}
          
          {breakSession?.data && (
            <button className="button" onClick={handleEndBreak}>
              Завершить перерыв
            </button>
          )}
          
          {workSession?.data && (
            <button className="button secondary" onClick={handleEndWork}>
              Завершить работу
            </button>
          )}
        </div>
      )}
      
      {!workSession?.data && !breakSession?.data && (
        <p>Нет активной сессии</p>
      )}
    </div>
  )
}

export default Timer