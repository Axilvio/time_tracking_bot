import React from 'react'

interface FilterControlsProps {
  filter: {
    type: string
    startDate: string
    endDate: string
  }
  onChange: (filter: any) => void
}

const FilterControls: React.FC<FilterControlsProps> = ({ filter, onChange }) => {
  const handleTypeChange = (type: string) => {
    onChange({ ...filter, type })
  }

  const handleStartDateChange = (startDate: string) => {
    onChange({ ...filter, startDate })
  }

  const handleEndDateChange = (endDate: string) => {
    onChange({ ...filter, endDate })
  }

  return (
    <div className="filter-controls">
      <div className="form-group">
        <label>Тип:</label>
        <div className="filter-options">
          <button
            className={`button ${filter.type === 'all' ? '' : 'secondary'}`}
            onClick={() => handleTypeChange('all')}
          >
            Все
          </button>
          <button
            className={`button ${filter.type === 'work' ? '' : 'secondary'}`}
            onClick={() => handleTypeChange('work')}
          >
            Работа
          </button>
          <button
            className={`button ${filter.type === 'break' ? '' : 'secondary'}`}
            onClick={() => handleTypeChange('break')}
          >
            Перерывы
          </button>
          <button
            className={`button ${filter.type === 'leave' ? '' : 'secondary'}`}
            onClick={() => handleTypeChange('leave')}
          >
            Отпуска
          </button>
        </div>
      </div>

      <div className="form-group">
        <label>Начальная дата:</label>
        <input
          type="date"
          className="input"
          value={filter.startDate}
          onChange={(e) => handleStartDateChange(e.target.value)}
        />
      </div>

      <div className="form-group">
        <label>Конечная дата:</label>
        <input
          type="date"
          className="input"
          value={filter.endDate}
          onChange={(e) => handleEndDateChange(e.target.value)}
        />
      </div>
    </div>
  )
}

export default FilterControls