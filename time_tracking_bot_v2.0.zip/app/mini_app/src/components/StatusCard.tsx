import React from 'react'

interface StatusCardProps {
  isWorking: boolean
  isOnBreak: boolean
  isOnLeave: boolean
  leaveType?: string
  isLoading: boolean
}

const StatusCard: React.FC<StatusCardProps> = ({
  isWorking,
  isOnBreak,
  isOnLeave,
  leaveType,
  isLoading,
}) => {
  const getStatusText = () => {
    if (isLoading) return 'Загрузка...'
    if (isOnLeave) {
      const leaveTypeText = {
        vacation: 'отпуске',
        sick_leave: 'больничном',
        day_off: 'отгуле',
      }[leaveType || ''] || 'отпуске'

      return `На ${leaveTypeText}`
    }
    if (isWorking && isOnBreak) return 'На перерыве'
    if (isWorking) return 'На работе'
    return 'Не на работе'
  }

  const getStatusClass = () => {
    if (isLoading) return ''
    if (isOnLeave) return 'status leave'
    if (isWorking && isOnBreak) return 'status break'
    if (isWorking) return 'status working'
    return 'status off'
  }

  return (
    <div className="card">
      <h3>Ваш статус</h3>
      <div className={`status ${getStatusClass()}`}>
        {getStatusText()}
      </div>
    </div>
  )
}

export default StatusCard