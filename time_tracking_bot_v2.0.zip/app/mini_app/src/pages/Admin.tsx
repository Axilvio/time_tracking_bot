import React, { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../contexts/AuthContext'
import { statsApi } from '../api/stats'
import UserManagement from '../components/UserManagement'
import NotificationSender from '../components/NotificationSender'

const Admin: React.FC = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('stats') // 'stats', 'users', 'notifications'
  const [period, setPeriod] = useState({
    startDate: '',
    endDate: '',
  })
  const queryClient = useQueryClient()

  // Check if user is admin
  if (!user?.is_admin) {
    return (
      <div className="container">
        <div className="card">
          <h2>Доступ запрещен</h2>
          <p>У вас нет прав для доступа к этой странице.</p>
        </div>
      </div>
    )
  }

  // Fetch admin stats
  const { data: adminStats } = useQuery({
    queryKey: ['adminStats', period.startDate, period.endDate],
    queryFn: () => statsApi.getAdminStats({
      start_date: period.startDate,
      end_date: period.endDate,
    }),
    enabled: !!period.startDate && !!period.endDate,
  })

  return (
    <div className="container">
      <div className="card">
        <h2>Админ-панель</h2>

        <div className="nav">
          <div
            className={`nav-item ${activeTab === 'stats' ? 'active' : ''}`}
            onClick={() => setActiveTab('stats')}
          >
            Статистика
          </div>
          <div
            className={`nav-item ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            Пользователи
          </div>
          <div
            className={`nav-item ${activeTab === 'notifications' ? 'active' : ''}`}
            onClick={() => setActiveTab('notifications')}
          >
            Уведомления
          </div>
        </div>
      </div>

      {activeTab === 'stats' && (
        <div className="card">
          <h3>Статистика команды</h3>

          <div className="form-group">
            <label>Начальная дата:</label>
            <input
              type="date"
              className="input"
              value={period.startDate}
              onChange={(e) => setPeriod({ ...period, startDate: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label>Конечная дата:</label>
            <input
              type="date"
              className="input"
              value={period.endDate}
              onChange={(e) => setPeriod({ ...period, endDate: e.target.value })}
            />
          </div>

          {adminStats?.data && (
            <div className="stats-grid">
              <div className="stat-item">
                <div className="stat-value">{adminStats.data.total_users}</div>
                <div className="stat-label">Всего пользователей</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{adminStats.data.active_users}</div>
                <div className="stat-label">Активных пользователей</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{adminStats.data.total_work_time}</div>
                <div className="stat-label">Общее время работы</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{adminStats.data.effective_work_time}</div>
                <div className="stat-label">Эффективное время работы</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{adminStats.data.average_work_time_per_user}</div>
                <div className="stat-label">Среднее время работы на пользователя</div>
              </div>
            </div>
          )}

          {adminStats?.data?.top_performers && (
            <div className="card">
              <h4>Топ performers</h4>
              <table className="table">
                <thead>
                  <tr>
                    <th>ID пользователя</th>
                    <th>Общее время работы</th>
                  </tr>
                </thead>
                <tbody>
                  {adminStats.data.top_performers.map((performer: any, index: number) => (
                    <tr key={index}>
                      <td>{performer.user_id}</td>
                      <td>{performer.total_work_time}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {activeTab === 'users' && <UserManagement />}

      {activeTab === 'notifications' && <NotificationSender />}
    </div>
  )
}

export default Admin