import React, { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { statsApi } from '../api/stats'
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, LineElement, PointElement } from 'react-chartjs-2'
import { Bar, Line } from 'react-chartjs-2'
import PeriodSelector from '../components/PeriodSelector'

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, LineElement, PointElement)

const Stats: React.FC = () => {
  const [period, setPeriod] = useState({
    type: 'week', // 'week', 'month', 'custom'
    startDate: '',
    endDate: '',
  })

  // Fetch stats based on period
  const { data: weeklyStats } = useQuery({
    queryKey: ['weeklyStats', period.startDate],
    queryFn: () => statsApi.getWeeklyStats({
      week_start: period.startDate,
    }),
    enabled: period.type === 'week',
  })

  const { data: monthlyStats } = useQuery({
    queryKey: ['monthlyStats', period.startDate],
    queryFn: () => statsApi.getMonthlyStats({
      year: period.startDate ? new Date(period.startDate).getFullYear() : new Date().getFullYear(),
      month: period.startDate ? new Date(period.startDate).getMonth() + 1 : new Date().getMonth() + 1,
    }),
    enabled: period.type === 'month',
  })

  const { data: customStats } = useQuery({
    queryKey: ['customStats', period.startDate, period.endDate],
    queryFn: () => statsApi.getWorkSessionStats({
      start_date: period.startDate,
      end_date: period.endDate,
    }),
    enabled: period.type === 'custom' && period.startDate && period.endDate,
  })

  const getStatsData = () => {
    switch (period.type) {
      case 'week':
        return weeklyStats?.data
      case 'month':
        return monthlyStats?.data
      case 'custom':
        return customStats?.data
      default:
        return null
    }
  }

  const stats = getStatsData()

  // Prepare chart data
  const getChartData = () => {
    if (!stats || !stats.sessions) return null

    const labels = stats.sessions.map((session: any) => session.date)
    const workTimeData = stats.sessions.map((session: any) => {
      // Convert duration string to hours
      const match = session.duration.match(/(\d+)h (\d+)m/)
      if (match) {
        return parseInt(match[1]) + parseInt(match[2]) / 60
      }
      return 0
    })
    const breakTimeData = stats.sessions.map((session: any) => {
      // Convert break time string to hours
      const match = session.break_time.match(/(\d+)h (\d+)m/)
      if (match) {
        return parseInt(match[1]) + parseInt(match[2]) / 60
      }
      return 0
    })

    return {
      labels,
      datasets: [
        {
          label: 'Время работы (часы)',
          data: workTimeData,
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1,
        },
        {
          label: 'Время перерывов (часы)',
          data: breakTimeData,
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          borderColor: 'rgba(255, 99, 132, 1)',
          borderWidth: 1,
        },
      ],
    }
  }

  const chartData = getChartData()

  return (
    <div className="container">
      <div className="card">
        <h2>Статистика</h2>

        <PeriodSelector period={period} onChange={setPeriod} />
      </div>

      {stats && (
        <>
          <div className="card">
            <h3>Общая статистика</h3>
            <div className="stats-grid">
              <div className="stat-item">
                <div className="stat-value">{stats.total_work_time}</div>
                <div className="stat-label">Общее время работы</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{stats.total_break_time}</div>
                <div className="stat-label">Общее время перерывов</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{stats.effective_work_time}</div>
                <div className="stat-label">Эффективное время работы</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{stats.work_days}</div>
                <div className="stat-label">Рабочих дней</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{stats.average_work_time}</div>
                <div className="stat-label">Среднее время работы</div>
              </div>
              <div className="stat-item">
                <div className="stat-value">{stats.overtime}</div>
                <div className="stat-label">Переработки</div>
              </div>
            </div>
          </div>

          {chartData && (
            <div className="card">
              <h3>График работы</h3>
              <Bar data={chartData} />
            </div>
          )}
        </>
      )}
    </div>
  )
}

export default Stats