import React, { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { workApi } from '../api/work'
import { breaksApi } from '../api/breaks'
import LocationSelector from '../components/LocationSelector'
import TimeEditor from '../components/TimeEditor'

const Work: React.FC = () => {
  const [location, setLocation] = useState('')
  const [editingSession, setEditingSession] = useState<any>(null)
  const queryClient = useQueryClient()

  // Fetch current work session
  const { data: workSession } = useQuery({
    queryKey: ['currentWorkSession'],
    queryFn: () => workApi.getCurrentWorkSession(),
  })

  // Fetch work history
  const { data: workHistory } = useQuery({
    queryKey: ['workHistory'],
    queryFn: () => workApi.getWorkHistory(),
  })

  // Start work mutation
  const startWorkMutation = useMutation({
    mutationFn: workApi.startWork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentWorkSession'] })
      queryClient.invalidateQueries({ queryKey: ['workHistory'] })
    },
  })

  // End work mutation
  const endWorkMutation = useMutation({
    mutationFn: workApi.endWork,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentWorkSession'] })
      queryClient.invalidateQueries({ queryKey: ['workHistory'] })
    },
  })

  // Edit work session mutation
  const editWorkSessionMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) =>
      workApi.editWorkSession(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workHistory'] })
      setEditingSession(null)
    },
  })

  const handleStartWork = () => {
    if (!location) {
      alert('Пожалуйста, выберите местоположение')
      return
    }

    startWorkMutation.mutate({ location })
  }

  const handleEndWork = () => {
    endWorkMutation.mutate()
  }

  const handleEditSession = (session: any) => {
    setEditingSession(session)
  }

  const handleSaveEdit = (data: any) => {
    if (!editingSession) return

    editWorkSessionMutation.mutate({
      id: editingSession.id,
      data,
    })
  }

  return (
    <div className="container">
      <div className="card">
        <h2>Работа</h2>

        {workSession?.data ? (
          <div>
            <p>Текущая сессия начата: {new Date(workSession.data.start).toLocaleString()}</p>
            <p>Местоположение: {workSession.data.location}</p>
            <button className="button" onClick={handleEndWork}>
              Завершить работу
            </button>
          </div>
        ) : (
          <div>
            <LocationSelector value={location} onChange={setLocation} />
            <button
              className="button"
              onClick={handleStartWork}
              disabled={startWorkMutation.isLoading}
            >
              Начать работу
            </button>
          </div>
        )}
      </div>

      <div className="card">
        <h3>История работы</h3>

        {workHistory?.data?.length ? (
          <table className="table">
            <thead>
              <tr>
                <th>Дата</th>
                <th>Начало</th>
                <th>Окончание</th>
                <th>Местоположение</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              {workHistory.data.map((session: any) => (
                <tr key={session.id}>
                  <td>{new Date(session.start).toLocaleDateString()}</td>
                  <td>{new Date(session.start).toLocaleTimeString()}</td>
                  <td>
                    {session.end
                      ? new Date(session.end).toLocaleTimeString()
                      : 'Не завершено'}
                  </td>
                  <td>{session.location}</td>
                  <td>
                    <button
                      className="button secondary"
                      onClick={() => handleEditSession(session)}
                    >
                      Изменить
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>У вас еще нет рабочих сессий.</p>
        )}
      </div>

      {editingSession && (
        <TimeEditor
          session={editingSession}
          onSave={handleSaveEdit}
          onCancel={() => setEditingSession(null)}
        />
      )}
    </div>
  )
}

export default Work