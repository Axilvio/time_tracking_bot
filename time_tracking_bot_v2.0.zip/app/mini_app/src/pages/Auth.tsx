import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { useTelegram } from '../hooks/useTelegram'

const Auth: React.FC = () => {
  const { login } = useAuth()
  const { tg } = useTelegram()
  const navigate = useNavigate()

  useEffect(() => {
    if (tg) {
      // Get Telegram init data
      const initData = tg.initData || ''
      
      // Authenticate with the backend
      login(initData)
        .catch(error => {
          console.error('Authentication failed:', error)
        })
    }
  }, [tg, login])

  return (
    <div className="container">
      <div className="card">
        <h2>Авторизация...</h2>
        <p>Пожалуйста, подождите, пока мы проверяем ваши данные.</p>
      </div>
    </div>
  )
}

export default Auth