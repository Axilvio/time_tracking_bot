import React, { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { workApi } from '../api/work'
import { breaksApi } from '../api/breaks'
import { leavesApi } from '../api/leaves'
import FilterControls from '../components/FilterControls'

const History: React.FC = () => {
  const [filter, setFilter] = useState({
    type: 'all', // 'all', 'work', 'break', 'leave'
    startDate: '',
    endDate: '',
  })

  // Fetch work history
  const { data: workHistory } = useQuery({
    queryKey: ['workHistory'],
    queryFn: () => workApi.getWorkHistory(),
  })

  // Fetch break history
  const { data: breakHistory } = useQuery({
    queryKey: ['breakHistory'],
    queryFn: () => breaksApi.getBreakHistory(),
  })

  // Fetch leave history
  const { data: leaveHistory } = useQuery({
    queryKey: ['leaveHistory'],
    queryFn: () => leavesApi.getLeaveHistory(),
  })

  // Filter data based on filter state
  const getFilteredData = () => {
    let data = []

    if (filter.type === 'all' || filter.type === 'work') {
      if (workHistory?.data) {
        data = data.concat(
          workHistory.data.map((item: any) => ({ ...item, type: 'work' }))
        )
      }
    }

    if (filter.type === 'all' || filter.type === 'break') {
      if (breakHistory?.data) {
        data = data.concat(
          breakHistory.data.map((item: any) => ({ ...item, type: 'break' }))
        )
      }
    }

    if (filter.type === 'all' || filter.type === 'leave') {
      if (leaveHistory?.data) {
        data = data.concat(
          leaveHistory.data.map((item: any) => ({ ...item, type: 'leave' }))
        )
      }
    }

    // Sort by date (newest first)
    data.sort((a, b) => {
      const dateA = new Date(a.start || a.start_date)
      const dateB = new Date(b.start || b.start_date)
      return dateB.getTime() - dateA.getTime()
    })

    // Filter by date range if provided
    if (filter.startDate) {
      const startDate = new Date(filter.startDate)
      data = data.filter(item => {
        const itemDate = new Date(item.start || item.start_date)
        return itemDate >= startDate
      })
    }

    if (filter.endDate) {
      const endDate = new Date(filter.endDate)
      data = data.filter(item => {
        const itemDate = new Date(item.end || item.end_date || item.start || item.start_date)
        return itemDate <= endDate
      })
    }

    return data
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'work':
        return 'Работа'
      case 'break':
        return 'Перерыв'
      case 'leave':
        return 'Отпуск'
      default:
        return type
    }
  }

  const getTypeClass = (type: string) => {
    switch (type) {
      case 'work':
        return 'status working'
      case 'break':
        return 'status break'
      case 'leave':
        return 'status leave'
      default:
        return ''
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h2>История</h2>

        <FilterControls filter={filter} onChange={setFilter} />
      </div>

      <div className="card">
        <h3>Записи</h3>

        {getFilteredData().length ? (
          <table className="table">
            <thead>
              <tr>
                <th>Тип</th>
                <th>Дата начала</th>
                <th>Дата окончания</th>
                <th>Длительность</th>
                <th>Детали</th>
              </tr>
            </thead>
            <tbody>
              {getFilteredData().map((item: any) => (
                <tr key={`${item.type}-${item.id}`}>
                  <td>
                    <span className={getTypeClass(item.type)}>
                      {getTypeLabel(item.type)}
                    </span>
                  </td>
                  <td>
                    {item.start
                      ? new Date(item.start).toLocaleString()
                      : new Date(item.start_date).toLocaleDateString()}
                  </td>
                  <td>
                    {item.end
                      ? new Date(item.end).toLocaleString()
                      : item.end_date
                      ? new Date(item.end_date).toLocaleDateString()
                      : 'Не завершено'}
                  </td>
                  <td>{item.duration || '-'}</td>
                  <td>
                    {item.type === 'work' && item.location && (
                      <span>Местоположение: {item.location}</span>
                    )}
                    {item.type === 'leave' && item.reason && (
                      <span>Причина: {item.reason}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>Нет записей, соответствующих выбранным фильтрам.</p>
        )}
      </div>
    </div>
  )
}

export default History