import React, { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useAuth } from '../contexts/AuthContext'
import { workApi } from '../api/work'
import { breaksApi } from '../api/breaks'
import { leavesApi } from '../api/leaves'
import StatusCard from '../components/StatusCard'
import Timer from '../components/Timer'
import Buttons from '../components/Buttons'

const Dashboard: React.FC = () => {
  const { user } = useAuth()
  const [currentTime, setCurrentTime] = useState(new Date())

  // Update current time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  // Fetch current work session
  const { data: workSession, isLoading: workLoading } = useQuery({
    queryKey: ['currentWorkSession'],
    queryFn: () => workApi.getCurrentWorkSession(),
    refetchInterval: 30000, // Refetch every 30 seconds
  })

  // Fetch current break session
  const { data: breakSession, isLoading: breakLoading } = useQuery({
    queryKey: ['currentBreakSession'],
    queryFn: () => breaksApi.getCurrentBreakSession(),
    refetchInterval: 30000, // Refetch every 30 seconds
  })

  // Fetch current leave periods
  const { data: leavePeriods, isLoading: leaveLoading } = useQuery({
    queryKey: ['currentLeavePeriods'],
    queryFn: () => leavesApi.getCurrentLeavePeriods(),
    refetchInterval: 30000, // Refetch every 30 seconds
  })

  const isWorking = !!workSession?.data
  const isOnBreak = !!breakSession?.data
  const isOnLeave = !!leavePeriods?.data?.length

  return (
    <div className="container">
      <div className="card">
        <h2>Добро пожаловать, {user?.first_name}!</h2>
        <p>Текущее время: {currentTime.toLocaleTimeString()}</p>
      </div>

      <StatusCard
        isWorking={isWorking}
        isOnBreak={isOnBreak}
        isOnLeave={isOnLeave}
        leaveType={leavePeriods?.data?.[0]?.type}
        isLoading={workLoading || breakLoading || leaveLoading}
      />

      {(isWorking || isOnBreak) && (
        <Timer
          startTime={isWorking ? workSession?.data?.start : breakSession?.data?.start}
          endTime={isOnBreak ? breakSession?.data?.end : null}
        />
      )}

      <Buttons
        isWorking={isWorking}
        isOnBreak={isOnBreak}
        isOnLeave={isOnLeave}
      />
    </div>
  )
}

export default Dashboard