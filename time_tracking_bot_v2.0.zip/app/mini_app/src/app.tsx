import React, { useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { useTelegram } from './hooks/useTelegram'
import { AuthProvider } from './contexts/AuthContext'
import Dashboard from './pages/Dashboard'
import Work from './pages/Work'
import History from './pages/History'
import Stats from './pages/Stats'
import Admin from './pages/Admin'
import Auth from './pages/Auth'
import Layout from './components/Layout'

function App() {
  const { tg, user } = useTelegram()

  useEffect(() => {
    if (tg) {
      tg.ready()
      tg.expand()
      
      // Set theme colors from Telegram
      if (tg.themeParams) {
        const root = document.documentElement
        root.style.setProperty('--tg-theme-bg-color', tg.themeParams.bg_color || '#ffffff')
        root.style.setProperty('--tg-theme-text-color', tg.themeParams.text_color || '#000000')
        root.style.setProperty('--tg-theme-button-color', tg.themeParams.button_color || '#0088cc')
        root.style.setProperty('--tg-theme-button-text-color', tg.themeParams.button_text_color || '#ffffff')
      }
    }
  }, [tg])

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="work" element={<Work />} />
              <Route path="history" element={<History />} />
              <Route path="stats" element={<Stats />} />
              <Route path="admin" element={<Admin />} />
            </Route>
          </Routes>
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  )
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
    mutations: {
      retry: 1,
    },
  },
})

export default App