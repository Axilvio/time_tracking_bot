import { apiClient } from './client'

export const statsApi = {
  getWeeklyStats: (params?: { week_start?: string }) =>
    apiClient.get('/stats/weekly', { params }),
  
  getMonthlyStats: (params?: { year?: number; month?: number }) =>
    apiClient.get('/stats/monthly', { params }),
  
  getUserStats: (userId: number, params: { start_date: string; end_date: string }) =>
    apiClient.get(`/stats/user/${userId}`, { params }),
  
  getAdminStats: (params: { start_date: string; end_date: string }) =>
    apiClient.get('/stats/admin/overview', { params }),
  
  getWorkSessionStats: (params: { start_date: string; end_date: string }) =>
    apiClient.get('/stats/work-sessions', { params }),
}