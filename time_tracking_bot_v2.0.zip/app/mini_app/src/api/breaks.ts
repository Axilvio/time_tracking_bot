import { apiClient } from './client'

export const breaksApi = {
  startBreak: () =>
    apiClient.post('/breaks/start'),
  
  endBreak: () =>
    apiClient.post('/breaks/end'),
  
  getCurrentBreakSession: () =>
    apiClient.get('/breaks/current'),
  
  getBreakHistory: (params?: { skip?: number; limit?: number }) =>
    apiClient.get('/breaks/history', { params }),
  
  editBreakSession: (id: number, data: { start_time?: string; end_time?: string }) =>
    apiClient.patch(`/breaks/${id}`, data),
}