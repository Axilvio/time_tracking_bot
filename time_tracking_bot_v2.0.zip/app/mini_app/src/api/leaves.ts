import { apiClient } from './client'

export const leavesApi = {
  startLeave: (data: { leave_type: string; start_date: string; end_date?: string; reason?: string }) =>
    apiClient.post('/leaves/start', data),
  
  endLeave: (data: { leave_type: string; end_date: string }) =>
    apiClient.post('/leaves/end', data),
  
  getCurrentLeavePeriods: () =>
    apiClient.get('/leaves/current'),
  
  getLeaveHistory: (params?: { skip?: number; limit?: number }) =>
    apiClient.get('/leaves/history', { params }),
  
  editLeavePeriod: (id: number, data: { start_date?: string; end_date?: string; reason?: string }) =>
    apiClient.patch(`/leaves/${id}`, data),
}