import { apiClient } from './client'

export const authApi = {
  login: (data: { initData: string }) =>
    apiClient.post('/auth/login', data),
  
  getUserInfo: () =>
    apiClient.get('/users/me'),
  
  refreshToken: (refreshToken: string) =>
    apiClient.post('/auth/refresh', { refresh_token: refreshToken }),
}