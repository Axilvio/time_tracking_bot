import { apiClient } from './client'

export const remindersApi = {
  createReminder: (data: { time: string; message: string }) =>
    apiClient.post('/reminders/', data),
  
  getReminders: (params?: { skip?: number; limit?: number }) =>
    apiClient.get('/reminders/', { params }),
  
  deleteReminder: (id: number) =>
    apiClient.delete(`/reminders/${id}`),
}