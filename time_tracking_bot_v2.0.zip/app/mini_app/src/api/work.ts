import { apiClient } from './client'

export const workApi = {
  startWork: (data: { location: string }) =>
    apiClient.post('/work/start', data),
  
  endWork: () =>
    apiClient.post('/work/end'),
  
  getCurrentWorkSession: () =>
    apiClient.get('/work/current'),
  
  getWorkHistory: (params?: { skip?: number; limit?: number }) =>
    apiClient.get('/work/history', { params }),
  
  editWorkSession: (id: number, data: { start_time?: string; end_time?: string }) =>
    apiClient.patch(`/work/${id}`, data),
}