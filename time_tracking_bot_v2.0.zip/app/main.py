import asyncio
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.websockets import WebSocket, WebSocketDisconnect

from app.api.routers import (
    auth, users, work, breaks, leaves, reminders, stats, admin, health
)
from app.api.middleware import AuthMiddleware, RateLimitMiddleware
from app.domain.events.base import event_bus
from app.domain.events.handlers import setup_event_handlers
from app.infrastructure.db.session import init_db
from app.infrastructure.redis.client import init_redis
from app.settings import settings
from app.logging import setup_logging

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle."""
    # Startup
    logger.info("Starting Arkady v2...")
    
    try:
        # Initialize database
        await init_db()
        logger.info("Database initialized")
        
        # Initialize Redis
        await init_redis()
        logger.info("Redis initialized")
        
        # Setup event handlers
        setup_event_handlers()
        logger.info("Event handlers initialized")
        
        # Start scheduler
        from app.domain.services.reminder_service import reminder_service
        await reminder_service.start_scheduler()
        logger.info("Scheduler started")
        
        yield
        
    except Exception as e:
        logger.error(f"Error during startup: {e}", exc_info=True)
        raise
    
    finally:
        # Shutdown
        logger.info("Shutting down Arkady v2...")
        
        try:
            # Stop scheduler
            from app.domain.services.reminder_service import reminder_service
            await reminder_service.stop_scheduler()
            logger.info("Scheduler stopped")
        except Exception as e:
            logger.error(f"Error during shutdown: {e}", exc_info=True)


# Create FastAPI app
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add custom middleware
app.add_middleware(AuthMiddleware)
app.add_middleware(RateLimitMiddleware)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
app.include_router(users.router, prefix="/api/users", tags=["users"])
app.include_router(work.router, prefix="/api/work", tags=["work"])
app.include_router(breaks.router, prefix="/api/breaks", tags=["breaks"])
app.include_router(leaves.router, prefix="/api/leaves", tags=["leaves"])
app.include_router(reminders.router, prefix="/api/reminders", tags=["reminders"])
app.include_router(stats.router, prefix="/api/stats", tags=["stats"])
app.include_router(admin.router, prefix="/api/admin", tags=["admin"])
app.include_router(health.router, prefix="/api/health", tags=["health"])


# WebSocket endpoint for real-time updates
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int):
    """Handle WebSocket connections for real-time updates."""
    await websocket.accept()
    
    try:
        # Store connection in event bus
        await event_bus.add_connection(user_id, websocket)
        
        # Keep connection alive
        while True:
            try:
                # Wait for message with timeout
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30)
                
                # Echo back for testing
                await websocket.send_text(f"Received: {data}")
            except asyncio.TimeoutError:
                # Send ping to keep connection alive
                await websocket.send_text("ping")
    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for user {user_id}")
    except Exception as e:
        logger.error(f"WebSocket error for user {user_id}: {e}", exc_info=True)
    finally:
        # Remove connection from event bus
        await event_bus.remove_connection(user_id, websocket)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
        log_level="info"
    )