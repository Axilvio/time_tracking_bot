import asyncio
from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from app.domain.models.user import User, UserRole
from app.domain.models.work_session import WorkSession, WorkLocation
from app.domain.models.break_session import BreakSession
from app.domain.models.leave_period import LeavePeriod, LeaveType
from app.domain.models.reminder import Reminder
from app.settings import settings


async def seed_test_data():
    """Seed test data for development."""
    engine = create_async_engine(settings.db_url)
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    async with async_session() as session:
        # Create admin user
        admin_user = User(
            telegram_id="123456789",
            first_name="Admin",
            last_name="User",
            username="adminuser",
            role=UserRole.ADMIN
        )
        
        session.add(admin_user)
        await session.flush()
        
        # Create regular users
        users = []
        for i in range(5):
            user = User(
                telegram_id=f"12345678{i}",
                first_name=f"User{i}",
                last_name=f"Test{i}",
                username=f"user{i}",
                role=UserRole.USER
            )
            
            session.add(user)
            users.append(user)
        
        await session.flush()
        
        # Create work sessions for each user
        for user in users:
            for i in range(5):
                start_date = datetime.now() - timedelta(days=i)
                start_time = start_date.replace(hour=9, minute=0, second=0, microsecond=0)
                end_time = start_time.replace(hour=17, minute=0, second=0, microsecond=0)
                
                work_session = WorkSession(
                    user_id=user.id,
                    start=start_time,
                    end=end_time,
                    location=WorkLocation.OFFICE
                )
                
                session.add(work_session)
                await session.flush()
                
                # Create a break session for each work session
                break_start = start_time.replace(hour=13, minute=0, second=0, microsecond=0)
                break_end = break_start.replace(hour=14, minute=0, second=0, microsecond=0)
                
                break_session = BreakSession(
                    work_session_id=work_session.id,
                    user_id=user.id,
                    start=break_start,
                    end=break_end
                )
                
                session.add(break_session)
        
        # Create leave periods
        for i, user in enumerate(users):
            leave_type = [LeaveType.VACATION, LeaveType.SICK_LEAVE, LeaveType.DAY_OFF][i % 3]
            start_date = datetime.now().date() + timedelta(days=i * 10)
            end_date = start_date + timedelta(days=5)
            
            leave_period = LeavePeriod(
                user_id=user.id,
                type=leave_type,
                start=start_date,
                end=end_date
            )
            
            session.add(leave_period)
        
        # Create reminders
        for user in users:
            reminder_time = datetime.now() + timedelta(hours=1)
            
            reminder = Reminder(
                user_id=user.id,
                time=reminder_time,
                message=f"Reminder for {user.first_name}"
            )
            
            session.add(reminder)
        
        await session.commit()
        
        return "Test data seeded successfully"


if __name__ == "__main__":
    asyncio.run(seed_test_data())