import asyncio
from datetime import datetime
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy import select, insert

from app.domain.models.user import User, UserRole
from app.domain.models.work_session import WorkSession, WorkLocation
from app.domain.models.break_session import BreakSession
from app.domain.models.leave_period import LeavePeriod, LeaveType
from app.settings import settings


async def migrate_data():
    """Migrate data from v1 to v2."""
    # This is a placeholder for migration logic
    # In a real implementation, you would connect to the v1 database
    # and migrate the data to the v2 database
    
    # For demonstration, we'll create some sample data
    engine = create_async_engine(settings.db_url)
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    async with async_session() as session:
        # Create a sample user
        user = User(
            telegram_id="123456789",
            first_name="Sample",
            last_name="User",
            username="sampleuser",
            role=UserRole.USER
        )
        
        session.add(user)
        await session.flush()
        
        # Create a sample work session
        work_session = WorkSession(
            user_id=user.id,
            start=datetime.now().replace(hour=9, minute=0, second=0, microsecond=0),
            end=datetime.now().replace(hour=17, minute=0, second=0, microsecond=0),
            location=WorkLocation.OFFICE
        )
        
        session.add(work_session)
        await session.flush()
        
        # Create a sample break session
        break_session = BreakSession(
            work_session_id=work_session.id,
            user_id=user.id,
            start=datetime.now().replace(hour=13, minute=0, second=0, microsecond=0),
            end=datetime.now().replace(hour=14, minute=0, second=0, microsecond=0)
        )
        
        session.add(break_session)
        
        # Create a sample leave period
        leave_period = LeavePeriod(
            user_id=user.id,
            type=LeaveType.VACATION,
            start=datetime.now().date(),
            end=(datetime.now().date().replace(day=datetime.now().day + 7))
        )
        
        session.add(leave_period)
        
        await session.commit()
        
        return "Migration completed successfully"


if __name__ == "__main__":
    asyncio.run(migrate_data())