import asyncio
import sys
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from app.domain.models.user import User, UserRole
from app.settings import settings


async def create_admin():
    """Create an admin user."""
    telegram_id = input("Enter Telegram ID for admin: ")
    
    engine = create_async_engine(settings.db_url)
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    async with async_session() as session:
        # Check if user already exists
        result = await session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        user = result.scalar_one_or_none()
        
        if user:
            # Update existing user to admin
            user.role = UserRole.ADMIN
            await session.commit()
            print(f"User {telegram_id} updated to admin role")
        else:
            # Create new admin user
            first_name = input("Enter first name: ")
            last_name = input("Enter last name (optional): ")
            username = input("Enter username (optional): ")
            
            admin_user = User(
                telegram_id=telegram_id,
                first_name=first_name,
                last_name=last_name,
                username=username,
                role=UserRole.ADMIN
            )
            
            session.add(admin_user)
            await session.commit()
            print(f"Admin user {telegram_id} created successfully")


if __name__ == "__main__":
    asyncio.run(create_admin())